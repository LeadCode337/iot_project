// src/eventBus.js
import mitt from 'mitt'
export default mitt()
