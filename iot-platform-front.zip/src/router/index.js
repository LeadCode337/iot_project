import NotFound from '@/views/404.vue'
import Main from '@/views/Main.vue'
import UserManage from '@/views/UserManage.vue'
import { ElMessage } from 'element-plus'
import { createRouter, createWebHistory } from 'vue-router'
import MqttUserManger from '../views/mqttUserManger.vue'
import MqttController from '../views/mqttController.vue'
import DevManage from '../views/devManage.vue'
import SensorManage from '../views/sensorManage.vue'
import SensorData from '../views/sensorData.vue'




const routes = [
  {
    path: '/',
    component: Main,
    meta: { title: '首页' },
    children: [
      {
        path: '',
        redirect: '/dashboard'
      },
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/Home.vue'),
        meta: { title: '首页' }
      },
      {
        path: 'user-manage',
        name: 'UserManage',
        component: UserManage,
        meta: {
          title: '用户管理',
          roles: ['admin', 'manager']
        }
      },

      {
        path: 'mqtt-user',
        name: 'mqttUserManager',
        component: MqttUserManger,
        meta: {
          title: 'MQTT用户管理',
          roles: ['admin', 'manager']
        }
      },


      {
        path: 'mqtt-acl',
        name: 'mqttController',
        component: MqttController,
        meta: {
          title: 'MQTT访问控制',
          roles: ['admin', 'manager']
        }
      },


      {
        path: 'device-manage',
        name: 'devManage',
        component: DevManage,
        meta: {
          title: '设备管理',
          roles: ['admin', 'manager']
        }
      },


      {
        path: 'sensor-manage',
        name: 'sensorManage',
        component: SensorManage,
        meta: {
          title: '传感器管理',
          roles: ['admin', 'manager']
        }
      },

      
      {
        path: 'sensor-data',
        name: 'sensorData',
        component: SensorData,
        meta: {
          title: '传感器数据管理',
          roles: ['admin', 'manager']
        }
      },

      {
        path: 'user-center',
        name: 'UserCenter',
        component: () => import('@/views/UserCenter.vue'),
        meta: { title: '个人中心' }
      }
    ]
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound,
    meta: { title: '404' }
  },
  {
    path: '/403',
    name: 'NoPermission',
    component: () => import('@/views/403.vue'),
    meta: { title: '403 无权限' }
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: { title: '登录' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true'
  const userRole = localStorage.getItem('role') // admin / user

  if (to.path === '/login' && isLoggedIn) {
    next('/')
  } else if (to.path !== '/login' && !isLoggedIn) {
    next('/login')
  } else if (to.meta.roles && !to.meta.roles.includes(userRole)) {
    ElMessage.error('无权限访问该页面')
    next('/') // 可跳转首页或 403 页面
  } else {
    next()
  }
})
export default router