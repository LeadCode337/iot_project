<script setup>
import { deleteDeviceApi, list, updateDeviceApi } from '@/api/device' // 新增updateDeviceApi
import { ElMessage, ElMessageBox } from 'element-plus'
import { onMounted, reactive, ref } from 'vue'

const queryForm = reactive({ name, pageNum: 1, pageSize: 10 })
const deviceList = ref([])
const total = ref(0)
const selectedDevices = ref([])
const isBatchDelete = ref(false)

// 新增：编辑相关变量
const dialogVisible = ref(false)
const editForm = ref({
  id: '',
  name: '',
  macAddress: '',
  mqttUsername: '',
  status: 1 // 默认在线状态
})

async function fetchData() {
  try {
    const res = await list(queryForm)
    if (res.code === 200 && res.data?.list) {
      deviceList.value = res.data.list;
      total.value = res.data.total
    } else {
      console.error('获取设备列表失败:', res.message)
    }
  } catch (err) {
    console.error('请求失败:', err)
  }
}

function handlePageChange(page) {
  queryForm.pageNum = page
  fetchData()
}

function deleteSingle(row) {
  ElMessageBox.confirm('确认删除吗?', '删除', {
    confirmButtonText: '删除',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteDeviceApi([row.id])
      .then(response => {
        if (response.code === 200) {
          ElMessage.success('用户删除成功');
          fetchData();
        } else {
          ElMessage.error('删除失败：' + response.message);
        }
      })
      .catch(() => {
        ElMessage.error('删除失败，请重试');
      });
  });
}

// 新增：打开编辑对话框
function openEditDialog(row) {
  // 复制当前行数据到编辑表单
  editForm.value = {
    id: row.id,
    name: row.name,
    macAddress: row.macAddress,
    mqttUsername: row.mqttUsername,
    status: row.status
  }
  dialogVisible.value = true
}

// 新增：提交编辑表单
function submitEdit() {

  alert("MQTT的用户名称"+editForm.value.mqttUsername);
  // 验证必填字段
  if (!editForm.value.name || !editForm.value.macAddress) {
    ElMessage.error('请填写设备名和MAC地址')
    return
  }

  // 调用更新API
  updateDeviceApi(editForm.value)
    .then(response => {
      if (response.code === 200) {
        ElMessage.success('设备更新成功')
        dialogVisible.value = false
        fetchData() // 刷新列表
      } else {
        ElMessage.error('更新失败：' + response.message)
      }
    })
    .catch(error => {
      console.error('更新请求失败:', error)
      ElMessage.error('更新失败，请重试')
    })
}

function batchDelete() {
  if (selectedDevices.value.length === 0) {
    ElMessage.error('请先选择数据');
    isBatchDelete.value = false;
    return;
  }
  const DevieIds = selectedDevices.value.map(device => device.id);
  ElMessageBox.confirm('确认删除选中吗?', '删除', {
    confirmButtonText: '删除',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    deleteDeviceApi(DevieIds)
      .then(response => {
        if (response.code === 200) {
          ElMessage.success('删除成功');
          fetchData();
          isBatchDelete.value = false;
        } else {
          ElMessage.error('删除失败：' + response.message);
        }
      })
      .catch(() => {
        ElMessage.error('删除失败，请重试');
      });
  });
}

function activateBatchDelete() {
  if (isBatchDelete.value) {
    batchDelete();
  } else {
    isBatchDelete.value = !isBatchDelete.value;
    selectedDevices.value = [];
  }
}

function handleSelectionChange(selection) {
  selectedDevices.value = selection;
}

onMounted(fetchData) 
</script>

<template>
  <el-card class="knife-card">
    <el-form :model="queryForm" label-width="80px" inline>
      <el-form-item label="设备">
        <el-input v-model="queryForm.name" placeholder="请输入设备名称" clearable />
      </el-form-item>
      <el-form-item>
        <el-row :gutter="5">
          <el-col :span="12">
            <el-button type="primary" @click="fetchData" style="width: 100%;">查询</el-button>
          </el-col>
          <el-col :span="12">
            <el-button type="danger" @click="activateBatchDelete" style="width: 100%;">批量删除</el-button>
          </el-col>
        </el-row>
      </el-form-item>
    </el-form>
  </el-card>

  <el-card class="knife-card">
    <el-table :data="deviceList" border style="width: 100%;" @selection-change="handleSelectionChange">
      <el-table-column v-if="isBatchDelete" type="selection" width="55"></el-table-column>
      <el-table-column label="ID" width="80">
        <template #default="scope">
          {{ (queryForm.pageNum - 1) * queryForm.pageSize + scope.$index + 1 }}
        </template>
      </el-table-column>
      <el-table-column prop="name" label="设备名" />
      <el-table-column prop="macAddress" label="MAC地址" />
      <el-table-column prop="mqttUsername" label="MQTT用户名" />
      <el-table-column prop="status" label="状态">
        <template #default="{ row }">
          <span>{{ row.status === 1 ? '在线' : '离线' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="createdAt" label="创建时间" />
      <el-table-column label="操作" width="180">
        <template #default="{ row }">
          <el-button link size="small" @click="openEditDialog(row)">修改</el-button>
          <el-divider direction="vertical" />
          <el-button link size="small" @click="deleteSingle(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <el-pagination @current-change="handlePageChange" :current-page="queryForm.pageNum" :page-size="queryForm.pageSize"
      :total="total" layout="total, prev, pager, next, jumper" style="margin-top: 20px;" />
  </el-card>

  <!-- 新增：编辑对话框 -->
  <el-dialog v-model="dialogVisible" title="修改设备信息" width="500px">
    <el-form :model="editForm" label-width="120px">
      <el-form-item label="设备ID">
        <el-input v-model="editForm.id" disabled />
      </el-form-item>
      <el-form-item label="设备名称" required>
        <el-input v-model="editForm.name" placeholder="请输入设备名称" />
      </el-form-item>
      <el-form-item label="MAC地址" required>
        <el-input v-model="editForm.macAddress" placeholder="请输入MAC地址" />
      </el-form-item>
      <el-form-item label="MQTT用户名">
        <el-input v-model="editForm.mqttUsername" placeholder="请输入MQTT用户名" />
      </el-form-item>
      <el-form-item label="设备状态">
        <el-radio-group v-model="editForm.status">
          <el-radio :label="1">在线</el-radio>
          <el-radio :label="0">离线</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitEdit">确认修改</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<style scoped>
.knife-card {
  margin-bottom: 20px;
  box-shadow: 0 2px 12px #f0f1f2;
}

.el-form-item {
  margin-bottom: 20px;
}

/* 新增：调整按钮间距 */
.el-button+.el-button {
  margin-left: 0;
}
</style>