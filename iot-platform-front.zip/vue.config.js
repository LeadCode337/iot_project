const { defineConfig } = require('@vue/cli-service')
// 引入 webpack 模块
const webpack = require('webpack')
module.exports = defineConfig({
  lintOnSave: false,
  transpileDependencies: true,

  devServer: {
    port: 8082, // 前端开发服务器运行在8081端口
    // http 代理配置
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8081', // 后端服务器地址
        changeOrigin: true,
        // pathRewrite: {
        //     '^/api': '' //如果需要移除/api前缀，可以启用此配置
        // }
      }
    }
  },
configureWebpack: {
    plugins: [
      // 现在可以正常使用 webpack 变量了
      new webpack.DefinePlugin({
        __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: false,
        __VUE_OPTIONS_API__: true,
        __VUE_PROD_DEVTOOLS__: false
      })
    ]
  }
})
