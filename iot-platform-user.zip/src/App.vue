<template>
  <!-- 根组件只有一个 router-view，用于显示 Main 或 404 等页面 -->
  <router-view />
</template>

<script setup>
// 无逻辑可以空着
</script>
