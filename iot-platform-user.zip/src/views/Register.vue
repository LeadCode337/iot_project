<template>
  <div class="login-page">
    <div class="dialog-wrapper">
      <div class="platform-title">用户注册</div>
      <form class="login-form" @submit.prevent="handleRegister">
        <el-input
          v-model="username"
          placeholder="请输入用户名"
          prefix-icon="el-icon-user"
          size="large"      
          clearable
          class="input-field"
        />
        <el-input
          v-model="nickname"
          placeholder="请输入昵称（可选）"
          prefix-icon="el-icon-user-solid"
          size="large"
          clearable
          class="input-field"
        />
        <el-input
          v-model="email"
          placeholder="请输入邮箱（可选）"
          prefix-icon="el-icon-message"
          size="large"
          clearable
          class="input-field"
        />
        <el-input
          v-model="password"
          placeholder="请输入密码"
          prefix-icon="el-icon-lock"
          size="large"
          show-password
          clearable
          class="input-field"
        />
        <el-input
          v-model="confirmPassword"
          placeholder="请确认密码"
          prefix-icon="el-icon-lock"
          size="large"
          show-password
          clearable
          class="input-field"
        />
        <el-button class="login-btn" type="primary" round size="large" native-type="submit">
          注册
        </el-button>
        <div class="to-login" @click="$router.push('/login')">已有账号？去登录</div>
      </form>
    </div>
  </div>
</template>

<script>
// 请根据实际API路径调整
import { register } from '@/api/user'
import { ElMessage } from 'element-plus'

export default {
  name: 'Register',
  data() {
    return {
      username: '',
      password: '',
      confirmPassword: '',
      nickname: '',
      email: ''
    }
  },
  methods: {
    async handleRegister() {
      if (!this.username || !this.password || !this.confirmPassword) {
        ElMessage.error('请填写完整信息')
        return
      }
      if (this.password !== this.confirmPassword) {
        ElMessage.error('两次输入的密码不一致')
        return
      }
      try {
        // 这里预留注册API调用
        const res = await register({ username: this.username, password: this.password, nickname: this.nickname, email: this.email })
        if (res.code === 200) {
          ElMessage.success('注册成功，请登录！')
          this.$router.push('/login')
        } else {
          ElMessage.error(res.message || '注册失败')
        }
        ElMessage.success('注册成功，请登录！')
        this.$router.push('/login')
      } catch (error) {
        console.error('注册异常：', error)
        ElMessage.error('注册异常，请稍后再试')
      }
    }
  }
}
</script>

<style scoped>
.login-page {
  width: 100vw;
  height: 100vh;
  background: linear-gradient(135deg, #f0f2f5 0%, #dfe9f3 100%);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  box-sizing: border-box;
}

.dialog-wrapper {
  width: 100%;
  max-width: 380px;
  background: #ffffff;
  border-radius: 24px;
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
  padding: 50px 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.platform-title {
  font-size: 26px;
  font-weight: 600;
  color: #333;
  margin-bottom: 30px;
  position: relative;
}

.platform-title::after {
  content: '';
  display: block;
  width: 50px;
  height: 3px;
  background: #6c5ce7;
  margin: 12px auto 0;
  border-radius: 2px;
}

.input-field {
  width: 100%;
  margin-bottom: 24px;
}

.login-btn {
  width: 100%;
  font-weight: 600;
  background: linear-gradient(90deg, #6c5ce7 0%, #00b894 100%);
  border: none;
  padding: 14px 0;
  font-size: 16px;
  border-radius: 30px;
  transition: background 0.3s;
}

.login-btn:hover {
  background: linear-gradient(90deg, #0984e3 0%, #00cec9 100%);
}

.to-login {
  width: 100%;
  text-align: right;
  font-size: 13px;
  color: #6c757d;
  margin-top: 18px;
  cursor: pointer;
}

.to-login:hover {
  color: #4dabf7;
}

@media (max-width: 400px) {
  .dialog-wrapper {
    padding: 40px 20px;
  }
  .platform-title {
    font-size: 22px;
  }
}
</style>