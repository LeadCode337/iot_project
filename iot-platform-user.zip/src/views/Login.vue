<template>
  <div class="login-page">
    <div class="dialog-wrapper">
      <div class="platform-title">IoT监控系统</div>

      <form v-if="activeTab === 'login'" class="login-form" @submit.prevent="handleLogin">
        <el-input
          v-model="username"
          placeholder="请输入用户名"
          prefix-icon="el-icon-user"
          size="large"
          clearable
          class="input-field"
        />
        <el-input
          v-model="password"
          placeholder="请输入密码"
          prefix-icon="el-icon-lock"
          size="large"
          show-password
          clearable
          class="input-field"
        />
        <div class="forgot-password">忘记密码？</div>
        <el-button class="login-btn" type="primary" round size="large" native-type="submit">
          登录
        </el-button>
        <div class="to-register" @click="$router.push('/register')">没有账号？去注册</div>
      </form>
    </div>
  </div>
</template>

<script>
import { login } from '@/api/user'
import { ElMessage } from 'element-plus'

export default {
  name: 'Login',
  data() {
    return {
      username: '',
      password: '',
      activeTab: 'login'
    }
  },
  methods: {
    async handleLogin() {
      try {
        const res = await login({ username: this.username, password: this.password })
        if (res.code === 200 && res.data?.token) {
          const { token, uid, role, avatar, nickname } = res.data
          localStorage.setItem('token', token)
          localStorage.setItem('uid', uid)
          localStorage.setItem('role', role)
          localStorage.setItem('isLoggedIn', 'true')
          localStorage.setItem('username', this.username)
          localStorage.setItem('avatarUrl', avatar || '') 
          localStorage.setItem('nickname', nickname) 

          ElMessage.success('登录成功！')
          this.$router.push('/')
        } else {
          ElMessage.error(res.message || '登录失败，请检查账号密码')
        }
      } catch (error) {
        console.error('登录异常：', error)
        ElMessage.error('登录异常，请稍后再试')
      }
    }
  }
}
</script>

<style scoped>
.login-page {
  width: 100vw;
  height: 100vh;
  background: linear-gradient(135deg, #f0f2f5 0%, #dfe9f3 100%);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  box-sizing: border-box;
}

.dialog-wrapper {
  width: 100%;
  max-width: 380px;
  background: #ffffff;
  border-radius: 24px;
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
  padding: 50px 30px;       /* 增加padding让框更高 */
  display: flex;
  flex-direction: column;
  align-items: center;
}

.platform-title {
  font-size: 26px;
  font-weight: 600;
  color: #333;
  margin-bottom: 30px;
  position: relative;
}

.platform-title::after {
  content: '';
  display: block;
  width: 50px;
  height: 3px;
  background: #6c5ce7;
  margin: 12px auto 0;
  border-radius: 2px;
}

.input-field {
  width: 100%;
  margin-bottom: 24px;   /* 增加输入框间距 */
}

.forgot-password {
  width: 100%;
  text-align: right;
  font-size: 13px;
  color: #6c757d;
  margin-bottom: 24px;   /* 加大与按钮的间距 */
  cursor: pointer;
}

.forgot-password:hover {
  color: #4dabf7;
}

.login-btn {
  width: 100%;
  font-weight: 600;
  background: linear-gradient(90deg, #6c5ce7 0%, #00b894 100%);
  border: none;
  padding: 14px 0;     /* 增加按钮高度 */
  font-size: 16px;
  border-radius: 30px;
  transition: background 0.3s;
}

.login-btn:hover {
  background: linear-gradient(90deg, #0984e3 0%, #00cec9 100%);
}

.to-register {
  width: 100%;
  text-align: right;
  font-size: 13px;
  color: #6c757d;
  margin-top: 18px;
  cursor: pointer;
}
.to-register:hover {
  color: #4dabf7;
}

@media (max-width: 400px) {
  .dialog-wrapper {
    padding: 40px 20px;  /* 小屏保留更大的内间距 */
  }

  .platform-title {
    font-size: 22px;
  }
}
</style>
