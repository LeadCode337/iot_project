package com.hqucc.ck.iot;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class IotApplicationTests {

//    @Test
//    public void contextLoads() {
//    }

    public static void main(String[] args) {
        System.out.println("hello world");
    }

}

