package com.hqucc.iot.config.mqtt;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.hqucc.iot.modules.dto.MqttPayload;
import com.hqucc.iot.modules.dto.MqttReading;
import com.hqucc.iot.modules.entity.Device;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.Sensor;
import com.hqucc.iot.modules.entity.SensorData;
import com.hqucc.iot.modules.service.*;
import com.hqucc.iot.modules.utils.SnowflakeIdWorker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class MqttInboundConfiguration {
    private static final Logger LOGGER = LoggerFactory.getLogger(MqttInboundConfiguration.class);

    private final MqttConfiguration mqttProp;
    private final ApplicationContext ctx;
    private final MqttUserService mqttUserService;

    @Autowired private DeviceService deviceService;
    @Autowired private SensorService sensorService;
    @Autowired private SensorDataService sensorDataService;
    @Autowired private MqttAclService mqttAclService;


    private static SnowflakeIdWorker idWorker = new SnowflakeIdWorker(1, 1);

    private final Map<String, Map<String, Long>> lastProcessedTimestamps = new ConcurrentHashMap<>();
    private final Map<String, String> beanNameToUsername = new ConcurrentHashMap<>();

    // 存储 adapterName -> username 的映射关系
    private final Map<String, String> adapterToUsername = new ConcurrentHashMap<>();


    @Bean
    public MessageChannel mqttInputChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageProducer inbound() {
        String beanName = mqttProp.getClientId() + "_sys_inbound";

        // 包装原始 channel，注入 adapterName header
        final MessageChannel originalChannel = mqttInputChannel();
        MessageChannel wrappedChannel = new MessageChannel() {
            @Override
            public boolean send(org.springframework.messaging.Message<?> message) {
                return originalChannel.send(
                        org.springframework.messaging.support.MessageBuilder
                                .fromMessage(message)
                                .setHeader("adapterName", beanName)
                                .build()
                );
            }

            @Override
            public boolean send(org.springframework.messaging.Message<?> message, long timeout) {
                return send(message);
            }
        };

        MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(
                beanName,
                mqttInClient(),
                mqttProp.getReceiveTopics().split(",")
        );
        adapter.setCompletionTimeout(10000);
        adapter.setQos(1);
        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setOutputChannel(wrappedChannel);
        adapter.setBeanName(beanName);
        adapterToUsername.put(beanName, mqttProp.getUsername());
        return adapter;
    }

    private MqttPahoClientFactory mqttInClient() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setServerURIs(mqttProp.getUrl().split(","));

        System.out.println("-----------------------测试获取账号"+mqttProp.getUsername());
        System.out.println("-----------------------测试获取密码"+mqttProp.getPassword());


        options.setUserName(mqttProp.getUsername().trim());
        options.setPassword(mqttProp.getPassword().trim().toCharArray());
        options.setKeepAliveInterval(mqttProp.getKeepalive());
        options.setConnectionTimeout(mqttProp.getTimeout());
        options.setMaxReconnectDelay(10000);
        options.setCleanSession(false);
        factory.setConnectionOptions(options);
        return factory;
    }

    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler() {
        return message -> {
            try {
                Object payload = message.getPayload();

                String beanName = (String) message.getHeaders().get("adapterName");
                if (StrUtil.isBlank(beanName)) {
                    log.warn("adapterName header missing, fallback to system adapter username");
                    beanName = mqttProp.getClientId() + "_sys_inbound";
                }
                String username = adapterToUsername.get(beanName);


                if (StrUtil.isBlank(username)) {
                    log.warn("Unable to resolve username from beanName header: {}", beanName);
                    return;
                }

                String topic = (String) message.getHeaders().get("mqtt_receivedTopic");

                if (!mqttAclService.isAllowed(username, topic, "subscribe")) {
                    log.warn("ACL 拒绝：用户 [{}] 无权限接收 topic [{}]", username, topic);
                    return;
                }

                log.info("\uD83D\uDCE9 Received MQTT message from user={} (beanName={})", username, beanName);

                MqttUser mqttUser = mqttUserService.getByUsername(username);
                if (mqttUser == null) {
                    log.warn("MQTT 用户未找到: {}", username);
                    return;
                }

                MqttPayload dto = JSONUtil.toBean(payload.toString(), MqttPayload.class);

                if (StrUtil.isBlank(dto.getMac())) {
                    LOGGER.warn("Invalid message, missing MAC address: {}", dto);
                    return;
                }

                Device device = ensureDeviceRegistered(dto.getMac(), dto.getDeviceName(), mqttUser.getMqttUid());
//                log.warn("device.mqttUid={} ({}), mqttUser.mqttUid={} ({})",
//                        device.getMqttUid(), device.getMqttUid().getClass().getSimpleName(),
//                        mqttUser.getMqttUid(), mqttUser.getMqttUid().getClass().getSimpleName());

                if (!Objects.equals(mqttUser.getMqttUid(), device.getMqttUid())) {
                    LOGGER.warn("设备不属于该 MQTT 用户，忽略");
                    return;
                }


                if (dto.getTimestamp() != null && isDuplicateMessage(dto.getMac(), "allReadings", dto.getTimestamp())) {
                    LOGGER.warn("Duplicate message detected: {}", dto);
                    return;
                }

                if (dto.getReadings() != null) {
                    for (MqttReading reading : dto.getReadings()) {
                        processSingleReading(device.getDeviceUid(), reading, dto.getTimestamp());
                    }
                }

                if (dto.getTimestamp() != null) {
                    updateLastProcessedTimestamp(dto.getMac(), "allReadings", dto.getTimestamp());
                }

            } catch (Exception e) {
                LOGGER.error("Failed to process MQTT message", e);
            }
        };
    }

    public void createAdapter(MqttUser user) {
        String username = user.getUsername();
        String plainPassword = user.getPlainPassword();


        log.info("创建 adapter 用户：username={}，password={}", username, plainPassword);


        System.out.println("创建 adapter 用户：username={}，password={}" +username);
        System.out.println("创建 adapter 用户：username={}，password={}  MqttInboundConfig"+plainPassword);
        if (StrUtil.isBlank(plainPassword)) {
            log.error("用户 {} 的 plain_password 为空，无法创建 MQTT adapter", username);
            return;
        }

        List<String> topics = mqttAclService.getSubscribableTopicsByUsername(username);
        if (topics.isEmpty()) {
            log.warn("用户 {} 没有订阅权限（mqtt_acl无记录），跳过 adapter 创建", username);
            return;
        }

        MqttConnectOptions opt = new MqttConnectOptions();
        opt.setServerURIs(mqttProp.getUrl().split(","));
        opt.setKeepAliveInterval(mqttProp.getKeepalive());
        opt.setConnectionTimeout(mqttProp.getTimeout());
        opt.setAutomaticReconnect(true);
        opt.setCleanSession(false);
        opt.setUserName(username);
        opt.setPassword(plainPassword.toCharArray());

        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        factory.setConnectionOptions(opt);

        String cid = mqttProp.getClientId() + "_" + username + "_in";
        String[] topicArray = topics.toArray(new String[0]);

        MqttPahoMessageDrivenChannelAdapter adapter =
                new MqttPahoMessageDrivenChannelAdapter(cid, factory, topicArray);
        adapter.setQos(1);
        adapter.setConverter(new DefaultPahoMessageConverter());

        // 注入 header
        final MessageChannel originalChannel = ctx.getBean("mqttInputChannel", MessageChannel.class);
        MessageChannel wrappedChannel = new MessageChannel() {
            @Override
            public boolean send(org.springframework.messaging.Message<?> message) {
                return originalChannel.send(
                        org.springframework.messaging.support.MessageBuilder
                                .fromMessage(message)
                                .setHeader("adapterName", cid)
                                .build()
                );
            }

            @Override
            public boolean send(org.springframework.messaging.Message<?> message, long timeout) {
                return send(message);
            }
        };

        adapter.setOutputChannel(wrappedChannel);

        adapterToUsername.put(cid, username);

        // 注册到 Spring 容器
        ConfigurableListableBeanFactory bf = (ConfigurableListableBeanFactory) ctx.getAutowireCapableBeanFactory();
        bf.initializeBean(adapter, cid + "Adapter");
        bf.registerSingleton(cid + "Adapter", adapter);
        adapter.start();

//        log.info("MQTT adapter 创建成功: user={}, topics={}", username, String.join(",", topics));
    }

    public List<String> getAclTopicsForUser(String username) {
        return mqttAclService.getSubscribableTopicsByUsername(username);
    }

    /**
     * 确保设备已注册 -- 返回含deviceUid的设备对象
     */
    private Device ensureDeviceRegistered(String macAddress, String deviceName, Long mqttUid) {
        Device existingDevice = deviceService.getByMacAndMqttUid(macAddress, mqttUid);

        if (existingDevice == null) {
            Device newDevice = new Device();
            newDevice.setDeviceUid(idWorker.nextId());
            newDevice.setMacAddress(macAddress);
            newDevice.setName(deviceName);
            newDevice.setStatus(1);
            newDevice.setCreatedAt(LocalDateTime.now());

            // 绑定当前 mqtt 用户
            deviceService.createDevice(newDevice, mqttUid);

//            LOGGER.info("Registered new device: deviceUid={}, mac={}, mqttUid={}",
//                    newDevice.getDeviceUid(), macAddress, mqttUid);
            return newDevice;
        } else {
            if (existingDevice.getStatus() == 0) {
                existingDevice.setStatus(1);
                existingDevice.setUpdatedAt(LocalDateTime.now());
                deviceService.updateDevice(existingDevice);
            }
            return existingDevice;
        }
    }

    /**
     * 处理单条传感器数据
     */
    private void processSingleReading(Long deviceUid, MqttReading reading, Long globalTimestamp) {
        if (reading == null) {
            LOGGER.warn("Reading is null, skip.");
            return;
        }
        String sensorType = reading.getType();
        Object readingValue = reading.getValue();
        if (StrUtil.isBlank(sensorType) || readingValue == null) {
//            LOGGER.warn("Reading type or value is null, skip. reading={}", reading);
            return;
        }

        // 1. 确保传感器已注册 (基于 deviceUid + sensorType)
        Sensor sensor = ensureSensorRegistered(deviceUid, sensorType);

        System.out.println("MqttInboundConfig-----------------------324"+sensor);


        // 2. 写数据(只插入符合阈值变化)
        saveSensorDataWithThreshold(sensor.getSensorUid(), sensorType, readingValue.toString());

        // 3. 其他逻辑(去重标记等)
        if (globalTimestamp != null) {
            LOGGER.debug("Processed reading with timestamp={}", globalTimestamp);
        }
    }

    /**
     * 确保传感器已注册 -- 返回含sensorUid的Sensor对象
     */
    private Sensor ensureSensorRegistered(Long deviceUid, String sensorType) {
        Sensor sensor = sensorService.getByDeviceUidAndType(deviceUid, sensorType);
        if (sensor != null) {
            return sensor;
        }
        Sensor newSensor = new Sensor();
        long sensorUid = idWorker.nextId();
        newSensor.setSensorUid(sensorUid);
        newSensor.setDeviceUid(deviceUid);
        newSensor.setSensorType(sensorType);
        newSensor.setCreatedAt(LocalDateTime.now());
        sensorService.createSensor(newSensor);

        LOGGER.info("Registered new sensor: sensorUid={}, deviceUid={}, type={}",
                sensorUid, deviceUid, sensorType);
        return newSensor;
    }

    /**
     * 只有在新旧读数差异 >= VALUE_THRESHOLD 时才插入新的记录
     */
    private static final float VALUE_THRESHOLD = 0.5f;

    private void saveSensorDataWithThreshold(Long sensorUid, String readingType, String newValueStr) {

        System.out.println("走到了保存数据的地方------------------MqttInboundConfig    364");

        // 查找最近一条记录(基于 sensorUid + type)
        SensorData latest = sensorDataService.getLatestBySensorUidAndType(sensorUid, readingType);

        System.out.println("查找最近的一条记录"+latest);
        // 没有记录，第一次插入
        if (latest == null) {
            SensorData data = new SensorData();
            data.setSensorUid(sensorUid);
            data.setReadingType(readingType);
            data.setReadingValue(newValueStr);
            data.setCreatedAt(LocalDateTime.now());
            sensorDataService.insertSensorData(data);
            LOGGER.info("第一次插入: sensorUid={}, type={}, value={}", sensorUid, readingType, newValueStr);
            return;
        }

        String oldValueStr = latest.getReadingValue();

        // 判断 newValueStr 是不是数字
        if (isNumeric(newValueStr) && isNumeric(oldValueStr)) {
            Float newValue = Float.parseFloat(newValueStr);
            Float oldValue = Float.parseFloat(oldValueStr);

            // 若差异足够大则插新行
            if (Math.abs(newValue - oldValue) >= VALUE_THRESHOLD) {
                SensorData data = new SensorData();
                data.setSensorUid(sensorUid);
                data.setReadingType(readingType);
                data.setReadingValue(newValueStr);
                data.setCreatedAt(LocalDateTime.now());
                sensorDataService.insertSensorData(data);
                LOGGER.info("数值变动>=阈值({}), old={}, new={}, 已插入新数据",
                        VALUE_THRESHOLD, oldValue, newValue);
            } else {
                LOGGER.debug("变化<阈值, 不插入: old={}, new={}", oldValue, newValue);
            }
        } else {
            // 字符串比较：只要不同就插入
            if (!newValueStr.equals(oldValueStr)) {
                SensorData data = new SensorData();
                data.setSensorUid(sensorUid);
                data.setReadingType(readingType);
                data.setReadingValue(newValueStr);
                data.setCreatedAt(LocalDateTime.now());
                sensorDataService.insertSensorData(data);
                LOGGER.info("字符串变化，插入新数据: old='{}', new='{}'", oldValueStr, newValueStr);
            } else {
                LOGGER.debug("字符串未变化，跳过存储: value='{}'", newValueStr);
            }
        }
    }

    /**
     * 判断一个字符串是不是数字
     */
    private boolean isNumeric(String str) {
        if (str == null) return false;
        try {
            Float.parseFloat(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /** 去重判断 */
    private boolean isDuplicateMessage(String macAddress, String type, Long timestamp) {
        lastProcessedTimestamps.putIfAbsent(macAddress, new ConcurrentHashMap<>());
        Long lastTimestamp = lastProcessedTimestamps.get(macAddress).get(type);
        return lastTimestamp != null && lastTimestamp.equals(timestamp);
    }

    /** 更新最后处理时间戳 */
    private void updateLastProcessedTimestamp(String macAddress, String type, Long timestamp) {
        lastProcessedTimestamps.putIfAbsent(macAddress, new ConcurrentHashMap<>());
        lastProcessedTimestamps.get(macAddress).put(type, timestamp);
    }
}
