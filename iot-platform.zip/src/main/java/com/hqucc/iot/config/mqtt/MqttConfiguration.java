package com.hqucc.iot.config.mqtt;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@Data
@ConfigurationProperties(prefix = "com.mqtt")
public class MqttConfiguration {
    private String url;
    private String clientId;
    private String receiveTopics;
    private String sendTopics;
    private String username;
    private String password;
    private int timeout;
    private int keepalive;
}