package com.hqucc.iot.config.mqtt;

import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.service.MqttUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.DefaultSingletonBeanRegistry;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.context.ApplicationContext;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class MqttAdapterInitializer {

    private final MqttUserService mqttUserService;
    private final MqttInboundConfiguration mqttInboundConfiguration;
    private final ApplicationContext ctx;
    private final MqttConfiguration mqttProp;

    private final Set<String> registeredUsernames = new HashSet<>();

    private final Map<String, Integer> userAclHashCache = new HashMap<>();

    @Scheduled(fixedDelay = 10000)
    public void refreshMqttAdapters() {
        List<MqttUser> latestUsers = mqttUserService.listAllNormalUsers();

        System.out.println("查到的数据"+latestUsers.toString());

        Set<String> latestUsernames = latestUsers.stream()
                .map(MqttUser::getUsername)
                .collect(Collectors.toSet());

        for (MqttUser user : latestUsers) {
            String username = user.getUsername();
            List<String> currentTopics = mqttInboundConfiguration.getAclTopicsForUser(username);
            int currentHash = currentTopics.hashCode();
            if (!registeredUsernames.contains(username)) {
                log.info("新用户，注册 MQTT adapter: {}", username);
                try {
                    mqttInboundConfiguration.createAdapter(user);
                    registeredUsernames.add(username);
                    userAclHashCache.put(username, currentHash);
                } catch (Exception e) {
                    log.error("注册失败: {}", username, e);
                }
                continue;
            }

            Integer cachedHash = userAclHashCache.get(username);
            if (cachedHash != null && cachedHash != currentHash) {
                log.info("ACL 变更，重新加载 MQTT adapter: {}", username);
                try {
                    String adapterBeanName = buildAdapterBeanName(username);
                    unregisterAdapter(adapterBeanName);

                    mqttInboundConfiguration.createAdapter(user);
                    userAclHashCache.put(username, currentHash);
                } catch (Exception e) {
                    log.error("重新加载失败: {}", username, e);
                }
            }
        }

        Set<String> removedUsers = new HashSet<>(registeredUsernames);
        removedUsers.removeAll(latestUsernames);

        for (String removedUsername : removedUsers) {
            String adapterBeanName = buildAdapterBeanName(removedUsername);
            try {
                unregisterAdapter(adapterBeanName);
                registeredUsernames.remove(removedUsername);
                userAclHashCache.remove(removedUsername);
                log.info("注销 MQTT 用户: {}", removedUsername);
            } catch (Exception e) {
                log.warn("注销失败 [{}]", adapterBeanName, e);
            }
        }
    }

    /**
     * 动态注销 Spring Bean 中的 MQTT adapter
     */
    private void unregisterAdapter(String adapterBeanName) {
        ConfigurableListableBeanFactory factory = (ConfigurableListableBeanFactory) ctx.getAutowireCapableBeanFactory();
        DefaultSingletonBeanRegistry registry = (DefaultSingletonBeanRegistry) factory;

        if (factory.containsSingleton(adapterBeanName)) {
            Object adapter = factory.getSingleton(adapterBeanName);
            if (adapter instanceof MqttPahoMessageDrivenChannelAdapter) {
                ((MqttPahoMessageDrivenChannelAdapter) adapter).stop();
                log.info("停止 adapter: {}", adapterBeanName);
            }
            registry.destroySingleton(adapterBeanName);
            log.info("移除 Bean: {}", adapterBeanName);
        }
    }

    private String buildAdapterBeanName(String username) {
        return mqttProp.getClientId() + "_" + username + "_inAdapter";
    }
}
