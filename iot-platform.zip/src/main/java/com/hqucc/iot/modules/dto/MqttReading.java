package com.hqucc.iot.modules.dto;

import lombok.Data;

@Data
public class MqttReading {
    private String type;
    private Object value;
}