package com.hqucc.iot.modules.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SensorPageDTO {
    private Integer id;
    private Long sensorUid;
    private String sensorType;
    private Long deviceUid;
    private String deviceName;
    private String mqttUsername;
    private LocalDateTime createdAt;
}