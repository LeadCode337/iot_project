package com.hqucc.iot.modules.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.util.List;

@Data
public class MqttAclQueryDTO {
    private String username;
    private String topic;
    private String action; // 可选字段，权限类型：subscribe/publish/deny

    @TableField(exist = false)
    private List<Long> mqttUidList;
}