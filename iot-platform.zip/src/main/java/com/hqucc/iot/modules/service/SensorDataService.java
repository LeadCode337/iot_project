package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.SensorDataPageDTO;
import com.hqucc.iot.modules.entity.SensorData;

import java.util.List;

public interface SensorDataService {
    Page<SensorDataPageDTO> list(SensorData query, Integer pageSize, Integer pageNum, List<Long> visibleSensorUids);
    SensorData getByDataId(Integer id);
    int deleteDataById(List<Integer> ids);
    SensorData getBySensorUid(Long sensorUid);
    boolean createData(SensorData data);
    List<SensorData> getByTimeRange(Long sensorUid, String startTime, String endTime);
    SensorData getLatestBySensorUidAndType(Long sensorUid, String readingType);
    boolean insertSensorData(SensorData data);
    boolean updateSensorData(SensorData data);
}