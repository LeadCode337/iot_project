package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.dto.SensorDataPageDTO;
import com.hqucc.iot.modules.entity.Device;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.SensorData;
import com.hqucc.iot.modules.service.DeviceService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.service.SensorDataService;
import com.hqucc.iot.modules.service.SensorService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Api(tags = "传感器数据管理")
@RestController
@RequestMapping("/api/sensorData")
public class SensorDataController {

    @Autowired
    private SensorDataService sensorDataService;
    @Autowired
    private MqttUserService mqttUserService;
    @Autowired
    private SensorService sensorService;
    @Autowired
    private DeviceService deviceService;

    @ApiOperation("分页查询传感器数据列表")
    @GetMapping("/list")
    @ResponseBody
    public CommonResult<CommonPage<SensorDataPageDTO>> list(
            SensorData sensorData,
            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
            @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum
    ) {
        Long ownerUid = CurrentUserUtils.getUid();
        String role = CurrentUserUtils.getRole();

        List<Long> visibleSensorUids = null;
        if ("user".equals(role)) {
            List<MqttUser> mqttUsers = mqttUserService.listByOwnerUid(ownerUid);
            List<Long> mqttUids = mqttUsers.stream().map(MqttUser::getMqttUid).collect(Collectors.toList());
            if (!mqttUids.isEmpty()) {
                List<Long> deviceUids = deviceService.getDeviceUidsByMqttUidList(mqttUids);
                visibleSensorUids = sensorService.getSensorUidsByDeviceUids(deviceUids);
            }
            if (visibleSensorUids == null || visibleSensorUids.isEmpty()) {
                visibleSensorUids = Collections.singletonList(-1L);
            }
        }

        Page<SensorDataPageDTO> page = sensorDataService.list(sensorData, pageSize, pageNum, visibleSensorUids);
        return CommonResult.success(CommonPage.restPage(page));
    }

    @ApiOperation("根据sensorUid获取传感器数据")
    @GetMapping("/{sensorUid}")
    @ResponseBody
    public CommonResult<SensorData> getSensorDataByUid(@PathVariable Long sensorUid) {
        Long userUid = CurrentUserUtils.getUid();
        SensorData sensorData = sensorDataService.getBySensorUid(sensorUid);
        if (sensorData != null && sensorData.getSensorUid().equals(userUid)) {
            return CommonResult.success(sensorData);
        }
        return CommonResult.failed("设备数据不存在或无权访问");
    }

    @ApiOperation("创建传感器数据")
    @PostMapping("/create")
    @ResponseBody
    public CommonResult<Boolean> create(@RequestBody SensorData sensorData) {
        boolean success = sensorDataService.createData(sensorData);
        if (success) {
            return CommonResult.success(true, "创建传感器数据成功");
        }
        return CommonResult.failed("创建传感器数据失败");
    }

    @ApiOperation("更新传感器数据")
    @PostMapping("/update")
    @ResponseBody
    public CommonResult<Boolean> update(@RequestBody SensorData sensorData) {
        boolean success = sensorDataService.updateSensorData(sensorData);
        if (success) {
            return CommonResult.success(true, "更新传感器数据成功");
        }
        return CommonResult.failed("更新传感器数据失败");
    }

    @ApiOperation("批量删除传感器数据")
    @PostMapping("/delete")
    public CommonResult<Integer> delete(@RequestBody List<Integer> ids) {
        int count = sensorDataService.deleteDataById(ids);
        if (count > 0) {
            return CommonResult.success(count, "成功删除 " + count + " 条传感器数据");
        }
        return CommonResult.failed("删除传感器数据失败");
    }

    @ApiOperation("按时间范围查询传感器数据 (示例)")
    @GetMapping("/range")
    @ResponseBody
    public CommonResult<List<SensorData>> getByTimeRange(
            @RequestParam("sensorUid") Long sensorUids,
            @RequestParam("startTime") String startTime,
            @RequestParam("endTime") String endTime
    ) {
        List<SensorData> list = sensorDataService.getByTimeRange(sensorUids, startTime, endTime);
        return CommonResult.success(list);
    }
}
