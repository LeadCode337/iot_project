package com.hqucc.iot.modules.vo;

import lombok.Data;

@Data
public class DeviceVO {
    private Integer id;
    private String name;
    private String macAddress;
    private String mqttUsername;
    private Integer status;
}
