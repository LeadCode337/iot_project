package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 用户实体
 */
@Data
@TableName("users")
public class User {

    @TableId
    private Integer id;  // 自增主键

    @TableField("uid")
    private Long uid;    // 雪花ID

    private String username;

    private String password;

    private String role; // admin / manager / student

    private String nickname; // 姓名或者昵称

    private String avatar;   // 头像 URL

    private String phone;    // 手机

    private String email;    // 邮箱

    @TableField("class_name")
    private String className;  // 学生班级（学生用）

    private String department; // 所在部门（老师用）

    @TableField("created_at")
    private LocalDateTime createdAt;
}

