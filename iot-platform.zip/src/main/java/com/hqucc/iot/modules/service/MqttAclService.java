package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hqucc.iot.modules.dto.MqttAclCreateDTO;
import com.hqucc.iot.modules.dto.MqttAclQueryDTO;
import com.hqucc.iot.modules.entity.MqttAcl;
import com.hqucc.iot.modules.entity.User;
import com.hqucc.iot.modules.vo.MqttCol;

import java.util.List;

public interface MqttAclService extends IService<MqttAcl> {

    Page<MqttAcl> list(MqttAclQueryDTO query, Integer pageSize, Integer pageNum);
    boolean createMqttAcl(MqttAclCreateDTO dto);
    List<String> getSubscribableTopicsByUsername(String username);
    boolean isAllowed(String username, String topic, String action);
    boolean editMqttAcl(MqttAcl dto);
    MqttAcl getByUid(Integer id);
}