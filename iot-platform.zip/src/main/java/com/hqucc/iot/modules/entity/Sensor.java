package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("sensors")
public class Sensor {

  @TableId
  private Integer id;

  @TableField("sensor_uid")
  private Long sensorUid;

  @TableField("device_uid")
  private Long deviceUid;

  @TableField("sensor_type")
  private String sensorType;

  @TableField("created_at")
  private LocalDateTime createdAt;
}











