package com.hqucc.iot.modules.dto;

import lombok.Data;

@Data
public class LoginResponseDTO {
    private String token;
    private Long expire;
    private Long uid;
    private String role;
    private String nickname; // 姓名或者昵称
    private String avatar;   // 头像 URL
}

