package com.hqucc.iot.modules.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class UpdateProfileDTO {

    @NotBlank(message = "昵称不能为空")
    private String nickname;

    private String phone;

    private String email;

    private String className;

    private String department;
}
