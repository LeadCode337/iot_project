package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.hqucc.iot.modules.dto.DevicePageDTO;
import com.hqucc.iot.modules.entity.Device;

import java.util.List;

public interface DeviceService {
    IPage<DevicePageDTO> list(String name, String macAddress, Integer status, List<Long> mqttUidList, int pageNum, int pageSize);
    Device getByDeviceUid(Long deviceUid);
    Device getById(Integer id);
    int deleteDevices(List<Integer> ids);
    boolean createDevice(Device device, Long mqttUid);
    boolean createDevice(Device device);
    boolean updateDevice(Device device);
    Device getByMacAndMqttUid(String mac, Long mqttUid);
    List<Long> getDeviceUidsByMqttUidList(List<Long> mqttUids);
    Device getByDeviceName(Integer id);
}
