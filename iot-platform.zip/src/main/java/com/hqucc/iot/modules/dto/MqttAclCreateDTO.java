package com.hqucc.iot.modules.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MqttAclCreateDTO {
    @NotBlank(message = "用户名不能为空")
    private String username;

    @NotBlank(message = "主题不能为空")
    private String topic;

    @NotBlank(message = "权限类型不能为空")
    private String action;

    @NotBlank(message = "权限值不能为空")
    private String permission;

    private Integer qos = 1;
    private Integer retain = 0;
}