package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.dto.DevicePageDTO;
import com.hqucc.iot.modules.entity.Device;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.service.DeviceService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import com.hqucc.iot.modules.vo.DeviceVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Api(tags = "设备管理")
@RestController
@RequestMapping("/api/device")
public class DeviceController {

    @Autowired
    private DeviceService deviceService;
    @Autowired
    private MqttUserService mqttUserService;

    @ApiOperation("分页查询设备列表")
    @GetMapping("/list")
    @ResponseBody
    public CommonResult<CommonPage<DevicePageDTO>> list(
            DevicePageDTO queryDTO,
            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
            @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum
    ) {
        Long ownerUid = CurrentUserUtils.getUid();
        String role = CurrentUserUtils.getRole();

        List<Long> mqttUids = null;

        if ("user".equals(role)) {
            List<MqttUser> mqttUsers = mqttUserService.listByOwnerUid(ownerUid);
            mqttUids = mqttUsers.stream()
                    .map(MqttUser::getMqttUid)
                    .collect(Collectors.toList());

            if (mqttUids.isEmpty()) {
                return CommonResult.success(CommonPage.restPage(new Page<>()));
            }
        }

        IPage<DevicePageDTO> page = deviceService.list(
                queryDTO.getName(),
                queryDTO.getMacAddress(),
                queryDTO.getStatus(),
                mqttUids,
                pageNum,
                pageSize
        );

        return CommonResult.success(CommonPage.restPage(page));
    }

    @ApiOperation("根据deviceUid获取设备详情")
    @GetMapping("/{deviceUid}")
    @ResponseBody
    public CommonResult<Device> getDeviceByUid(@PathVariable Long deviceUid) {
        Device device = deviceService.getByDeviceUid(deviceUid);
        if (device != null) {
            return CommonResult.success(device);
        }
        return CommonResult.failed("设备不存在");
    }

    @ApiOperation("创建设备")
    @PostMapping("/create")
    @ResponseBody
    public CommonResult<Boolean> create(@RequestBody Device device) {
        boolean success = deviceService.createDevice(device);
        return success ? CommonResult.success(true, "创建设备成功")
                : CommonResult.failed("创建设备失败");
    }

    @ApiOperation("更新设备信息")
    @PostMapping("/update")
    @ResponseBody
    public CommonResult<Boolean> update(@RequestBody DeviceVO deviceVO) {

        Device device = deviceService.getById(deviceVO.getId());

        if (deviceVO.getMqttUsername()==null) {
//          不更改mqtt用户
            device.setName(deviceVO.getName());
            device.setMacAddress(deviceVO.getMacAddress());
            device.setStatus(deviceVO.getStatus());

            boolean success = deviceService.updateDevice(device);

            if (success) {
                return CommonResult.success(true, "更新设备成功");
            }
            return CommonResult.failed("更新设备失败");
        } else {
            //更改mqtt的用户
            MqttUser mqttUser = mqttUserService.getByUsername(deviceVO.getMqttUsername());

            if (mqttUser==null){
                return CommonResult.failed("当前MQTT用户不存在");
            }

            Long mqttUid = mqttUser.getMqttUid();

            device.setMqttUid(mqttUid);
            device.setName(deviceVO.getName());
            device.setMacAddress(deviceVO.getMacAddress());
            device.setStatus(deviceVO.getStatus());

            boolean success = deviceService.updateDevice(device);

            if (success) {
                return CommonResult.success(true, "更新设备成功");
            }

            return CommonResult.failed("更新设备失败");
        }

    }

    @ApiOperation("根据ID获取设备")
    @GetMapping("/{id}")
    public CommonResult<Device> getDeviceById(@PathVariable("id") Integer id) {
        Device dev = deviceService.getById(id);
        if (dev != null) {
            return CommonResult.success(dev);
        }
        return CommonResult.failed("设备不存在");
    }

    @ApiOperation("批量删除设备")
    @PostMapping("/delete")
    public CommonResult<Integer> delete(@RequestBody List<Integer> ids) {
        int count = deviceService.deleteDevices(ids);
        if (count > 0) {
            return CommonResult.success(count, "成功删除 " + count + " 个设备");
        }
        return CommonResult.failed("删除设备失败");
    }


}
