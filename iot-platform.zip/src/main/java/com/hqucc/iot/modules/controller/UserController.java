package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.common.config.JwtProperties;
import com.hqucc.iot.common.utils.CosUtils;
import com.hqucc.iot.modules.dto.*;
import com.hqucc.iot.modules.entity.LoginLog;
import com.hqucc.iot.modules.entity.User;
import com.hqucc.iot.modules.service.LoginLogService;
import com.hqucc.iot.modules.service.UserService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import com.hqucc.iot.modules.utils.IPUtil;
import com.hqucc.iot.modules.utils.JwtUtils;
import io.jsonwebtoken.Claims;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@Api(tags = "用户管理")
@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired private UserService userService;
    @Autowired private LoginLogService loginLogService;
    @Autowired private JwtUtils jwtUtils;
    @Autowired private JwtProperties jwtProperties;
    @Autowired private CosUtils cosUtils;

    /** 分页查询用户列表（仅管理员可用） */
    @PreAuthorize("hasAnyAuthority('admin','manager')")
    @ApiOperation("分页查询用户列表")
    @GetMapping("/list")
    public CommonResult<CommonPage<User>> list(
            User user,
            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
            @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum) {
        Page<User> userPage = userService.list(user, pageSize, pageNum);
        return CommonResult.success(CommonPage.restPage(userPage));
    }

    /** 根据用户名查询用户 */
    @ApiOperation("根据用户名查询用户")
    @GetMapping("/by-username/{username}")
    public CommonResult<User> getUserByUsername(@PathVariable String username) {
        User user = userService.getUserByUsername(username);
        return user != null ? CommonResult.success(user) : CommonResult.failed("用户不存在");
    }

    /** 根据ID查询用户 */
    @ApiOperation("根据ID查询用户")
    @GetMapping("/by-id/{id}")
    public CommonResult<User> getUserById(@PathVariable Integer id) {
        User user = userService.getById(id);
        return user != null ? CommonResult.success(user) : CommonResult.failed("用户不存在");
    }

    /** 用户注册 */
    @ApiOperation("用户注册")
    @PostMapping("/register")
    public CommonResult<Boolean> register(@Valid @RequestBody RegisterRequestDTO request) {
        if (userService.getUserByUsername(request.getUsername()) != null) {
            return CommonResult.failed("用户名已存在");
        }
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        if (request.getNickname()!=null){
            user.setNickname(request.getNickname());
        }
        if (request.getEmail()!=null){
            user.setEmail(request.getEmail());
        }
        user.setRole("user");
        user.setCreatedAt(LocalDateTime.now());
        return userService.createUser(user) ? CommonResult.success(true, "注册成功") : CommonResult.failed("注册失败");
    }

    /** 用户登录 */
    @ApiOperation("用户登录")
    @PostMapping("/login")
    public CommonResult<LoginResponseDTO> login(@RequestBody LoginRequestDTO loginDTO, HttpServletRequest request) {

        System.out.println("登录功能");
        User user = userService.getUserByUsername(loginDTO.getUsername());
        if (user == null || !user.getPassword().equals(loginDTO.getPassword())) {
            return CommonResult.failed("用户名或密码错误");
        }

        LoginLog log = new LoginLog();
        log.setUid(user.getUid());
        log.setUsername(user.getUsername());
        log.setLoginTime(LocalDateTime.now());
        log.setIp(IPUtil.getClientIp(request));
        loginLogService.save(log);

        String token = jwtUtils.generateToken(user.getUid(), user.getRole());

        LoginResponseDTO dto = new LoginResponseDTO();
        dto.setToken(token);
        dto.setExpire(jwtProperties.getExpire());
        dto.setUid(user.getUid());
        dto.setRole(user.getRole());
        dto.setNickname(user.getNickname());
        dto.setAvatar(user.getAvatar());

        return CommonResult.success(dto, "登录成功");
    }

    /** 用户退出登录 */
    @ApiOperation("用户退出登录")
    @PostMapping("/logout")
    public CommonResult<String> logout(HttpServletRequest request) {
        String token = request.getHeader("Authorization");
        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7);
        }
        Claims claims = jwtUtils.parseToken(token);
        Long uid = claims.get("uid", Long.class);
        String username = userService.getByUid(uid).getUsername();

        LoginLog log = new LoginLog();
        log.setUid(uid);
        log.setUsername(username);
        log.setLoginTime(LocalDateTime.now());
        log.setIp(IPUtil.getClientIp(request));
        loginLogService.save(log);

        return CommonResult.success(null, "退出成功");
    }

    /** 批量删除用户 */
    @PreAuthorize("hasAnyAuthority('admin','manager')")
    @ApiOperation("批量删除用户")
    @PostMapping("/delete")
    public CommonResult<Integer> deleteUsers(@RequestBody List<Integer> ids) {
        int count = userService.deleteUsers(ids);
        return count > 0 ? CommonResult.success(count, "成功删除 " + count + " 个用户") : CommonResult.failed("删除失败");
    }

    /** 刷新Token */
    @ApiOperation("刷新Token")
    @GetMapping("/refresh")
    public CommonResult<LoginResponseDTO> refreshToken(@RequestHeader("Authorization") String token) {
        token = token.replace("Bearer ", "");
        Claims claims = jwtUtils.parseToken(token);

        Long uid = claims.get("uid", Long.class);
        String role = claims.get("role", String.class);
        String newToken = jwtUtils.generateToken(uid, role);

        LoginResponseDTO dto = new LoginResponseDTO();
        dto.setToken(newToken);
        dto.setExpire(jwtProperties.getExpire());
        dto.setUid(uid);
        dto.setRole(role);

        return CommonResult.success(dto, "Token刷新成功");
    }

    /** 创建管理员账号 */
    @PreAuthorize("hasAuthority('admin')")
    @ApiOperation("创建管理员账号")
    @PostMapping("/create-manager")
    public CommonResult<Boolean> createManager(@Valid @RequestBody RegisterRequestDTO request) {
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setRole("manager");
        user.setCreatedAt(LocalDateTime.now());

        return userService.createUser(user) ? CommonResult.success(true, "管理员创建成功") : CommonResult.failed("创建失败");
    }

    /** 管理员批量创建普通用户 */
    @PreAuthorize("hasAnyAuthority('admin','manager')")
    @ApiOperation("管理员批量创建用户")
    @PostMapping("/batch-create")
    public CommonResult<Integer> batchCreateUsers(@RequestBody List<RegisterRequestDTO> users) {
        int count = userService.batchCreateUsers(users);
        return count > 0 ? CommonResult.success(count, "成功创建 " + count + " 个用户") : CommonResult.failed("创建失败");
    }

    /** 修改当前用户密码 */
    @ApiOperation("修改密码")
    @PostMapping("/change-password")
    public CommonResult<Boolean> changePassword(@Valid @RequestBody ChangePasswordDTO changePasswordDTO) {
        Long uid = CurrentUserUtils.getUid();
        User user = userService.getByUid(uid);

        if (user == null) return CommonResult.failed("用户不存在");
        if (!user.getPassword().equals(changePasswordDTO.getOldPassword())) {
            return CommonResult.failed("原密码错误");
        }

        user.setPassword(changePasswordDTO.getNewPassword());
        return userService.updateUserPassword(user) ? CommonResult.success(true, "密码修改成功") : CommonResult.failed("密码修改失败");
    }

    /** 获取当前用户个人信息 */
    @ApiOperation("获取个人信息")
    @GetMapping("/profile")
    public CommonResult<User> getProfile() {
        Long uid = CurrentUserUtils.getUid();
        User user = userService.getByUid(uid);
        return user != null ? CommonResult.success(user) : CommonResult.failed("用户不存在");
    }

    /** 更新当前用户个人信息 */
    @ApiOperation("更新个人信息")
    @PostMapping("/profile")
    public CommonResult<Boolean> updateProfile(@Valid @RequestBody UpdateProfileDTO updateProfileDTO) {
        Long uid = CurrentUserUtils.getUid();
        User user = userService.getByUid(uid);

        if (user == null) return CommonResult.failed("用户不存在");

        user.setNickname(updateProfileDTO.getNickname());
        user.setPhone(updateProfileDTO.getPhone());
        user.setEmail(updateProfileDTO.getEmail());
        user.setClassName(updateProfileDTO.getClassName());
        user.setDepartment(updateProfileDTO.getDepartment());

        return userService.updateUserProfile(user) ? CommonResult.success(true, "资料更新成功") : CommonResult.failed("资料更新失败");
    }

    /** 上传并更新头像 */
    @ApiOperation("上传头像")
    @PostMapping("/update-avatar")
    public CommonResult<String> updateAvatar(@RequestParam("file") MultipartFile file) {
        String avatarUrl = cosUtils.uploadFile(file, "avatar");
        Long uid = CurrentUserUtils.getUid();

        boolean success = userService.updateUserAvatar(uid, avatarUrl);
        return success ? CommonResult.success(avatarUrl, "头像更新成功") : CommonResult.failed("头像更新失败");
    }
}
