package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("mqtt_user")
public class MqttUser {

  @TableId(type = IdType.AUTO)
  private Integer id;

  private String username;

  @TableField("password_hash")
  private String passwordHash;

  @TableField("is_superuser")
  private Boolean isSuperUser;

  private String salt;

  @TableField("owner_uid")
  private Long ownerUid;   // 外键 -> users.uid

  private LocalDateTime created;

  @TableField("plain_password")
  private String plainPassword;

  @TableField("mqtt_uid")
  private Long mqttUid;
}