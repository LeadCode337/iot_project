package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.entity.MqttUser;

import java.util.List;

public interface MqttUserService {
    Page<MqttUser> list(MqttUser mqttUser, Integer pageSize, Integer pageNum);
    Page<MqttUser> listByOwner(Long ownerUid, Integer pageSize, Integer pageNum);
    MqttUser getById(Integer id);
    boolean createUser(MqttUser mqttUser, String password);
    boolean updateUser(MqttUser mqttUser);
    boolean updatePasswordById(Integer id, String newPassword);
    List<MqttUser> listByOwnerUid(Long ownerUid);
    List<MqttUser> listAllNormalUsers();
    int deleteMqttUserById(List<Integer> ids);
    MqttUser getByUsername(String username);
}