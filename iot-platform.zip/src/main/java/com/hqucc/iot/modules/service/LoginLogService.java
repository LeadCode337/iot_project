package com.hqucc.iot.modules.service;

import com.hqucc.iot.modules.entity.LoginLog;

public interface LoginLogService {
    boolean save(LoginLog log);
}

