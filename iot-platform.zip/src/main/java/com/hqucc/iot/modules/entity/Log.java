package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 操作日志实体
 */
@Data
@TableName("logs")
public class Log {

    @TableId
    private Integer id;  // 自增主键

    @TableField("device_uid")
    private Long deviceUid;  // 外键 -> devices.device_uid

    private String action;    // 上线/下线/修改配置等

    private String description;

    @TableField("created_at")
    private LocalDateTime createdAt;
}
