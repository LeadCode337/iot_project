package com.hqucc.iot.modules.vo;

import lombok.Data;

@Data
public class MqttUserVO {
    private String userName;
    private String[] createTimeRange;
    private Integer pageSize;   //每页大小
    private Integer pageNum;  //当前页码


}
