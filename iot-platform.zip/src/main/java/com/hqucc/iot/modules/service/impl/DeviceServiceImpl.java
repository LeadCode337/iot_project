package com.hqucc.iot.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.DevicePageDTO;
import com.hqucc.iot.modules.entity.Device;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.mapper.DeviceMapper;
import com.hqucc.iot.modules.service.DeviceService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DeviceServiceImpl implements DeviceService {

    @Autowired
    private DeviceMapper deviceMapper;

    @Autowired
    private MqttUserService mqttUserService;

    @Override
    public IPage<DevicePageDTO> list(String name, String macAddress, Integer status, List<Long> mqttUidList, int pageNum, int pageSize) {
        Page<DevicePageDTO> page = new Page<>(pageNum, pageSize);
        return deviceMapper.selectDevicePageDTO(page, name, macAddress, status, mqttUidList);
    }

    @Override
    public Device getByDeviceUid(Long deviceUid) {
        if (deviceUid == null) return null;
        QueryWrapper<Device> wrapper = new QueryWrapper<>();
        wrapper.eq("device_uid", deviceUid).last("limit 1");
        return deviceMapper.selectOne(wrapper);
    }

    @Override
    public boolean createDevice(Device device) {
        Long ownerUid = CurrentUserUtils.getUid();
        List<MqttUser> mqttUsers = mqttUserService.listByOwnerUid(ownerUid);
        if (mqttUsers == null || mqttUsers.isEmpty()) {
            throw new IllegalStateException("当前用户尚未绑定任何 MQTT 账号");
        }

        // 默认选择第一个 mqtt_user 的 mqtt_uid
        device.setMqttUid(mqttUsers.get(0).getMqttUid());
        return deviceMapper.insert(device) > 0;
    }

    @Override
    public boolean createDevice(Device device, Long mqttUid) {
        if (mqttUid == null) {
            throw new IllegalArgumentException("mqttUid 不能为空");
        }
        device.setMqttUid(mqttUid);
        return deviceMapper.insert(device) > 0;
    }

    @Override
    public boolean updateDevice(Device device) {
        if (device == null || device.getDeviceUid() == null) {
            return false;
        }
        Device dbDev = getByDeviceUid(device.getDeviceUid());
        if (dbDev == null) {
            return false;
        }
        device.setId(dbDev.getId()); // 保留原自增ID
        return deviceMapper.updateById(device) > 0;
    }

    @Override
    public Device getById(Integer id) {
        return deviceMapper.selectById(id);
    }

    @Override
    public int deleteDevices(List<Integer> ids) {
        return deviceMapper.deleteBatchIds(ids);
    }

    @Override
    public List<Long> getDeviceUidsByMqttUidList(List<Long> mqttUids) {
        if (mqttUids == null || mqttUids.isEmpty()) return Collections.emptyList();

        QueryWrapper<Device> wrapper = new QueryWrapper<>();
        wrapper.in("mqtt_uid", mqttUids);
        List<Device> devices = deviceMapper.selectList(wrapper);
        return devices.stream()
                .map(Device::getDeviceUid)
                .collect(Collectors.toList());
    }

    @Override
    public Device getByDeviceName(Integer id) {

        Device device = deviceMapper.selectDeviceByName(id);
        return device;
    }

    public Device getByMacAndMqttUid(String mac, Long mqttUid) {
        QueryWrapper<Device> wrapper = new QueryWrapper<>();
        wrapper.eq("mac_address", mac).eq("mqtt_uid", mqttUid);
        return deviceMapper.selectOne(wrapper);
    }
}
