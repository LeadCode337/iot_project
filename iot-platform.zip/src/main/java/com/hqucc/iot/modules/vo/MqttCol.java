package com.hqucc.iot.modules.vo;

import lombok.Data;


@Data
public class MqttCol {

    private String username;

    private String topic;

    private String action;

    private String permission;

    private Integer id;


    private Integer qos = 1;
    private Integer retain = 0;

}
