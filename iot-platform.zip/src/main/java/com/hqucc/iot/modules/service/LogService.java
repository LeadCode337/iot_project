package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.entity.Log;

import java.util.List;

public interface LogService {

    Page<Log> list(Log log, Integer pageSize, Integer pageNum);

    boolean createLog(Log log);

    Log getById(Integer id);

    int deleteLogs(List<Integer> ids);
}
