package com.hqucc.iot.modules.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class MqttAclUpdateDTO {
    @NotNull(message = "ID 不能为空")
    private Integer id;

    private String topic;
    private String action;
}