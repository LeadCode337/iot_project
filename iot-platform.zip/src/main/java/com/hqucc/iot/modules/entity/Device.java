package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@TableName("devices")
public class Device {

  @TableId
  private Integer id;

  @TableField("device_uid")
  private Long deviceUid;

  @TableField("mqtt_uid")
  private Long mqttUid;

  private String name;

  @TableField("mac_address")
  private String macAddress;

  private Integer status;  // 1: 正常, 0: 离线

  @TableField("created_at")
  private LocalDateTime createdAt;

  @TableField("updated_at")
  private LocalDateTime updatedAt;

  @TableField(exist = false)
  private List<Long> mqttUidList;
}
