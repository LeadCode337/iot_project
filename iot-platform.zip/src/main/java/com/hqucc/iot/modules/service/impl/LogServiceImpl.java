package com.hqucc.iot.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.entity.Log;
import com.hqucc.iot.modules.mapper.LogMapper;
import com.hqucc.iot.modules.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LogServiceImpl implements LogService {

    @Autowired
    private LogMapper logMapper;

    @Override
    public Page<Log> list(Log log, Integer pageSize, Integer pageNum) {
        Page<Log> page = new Page<>(pageNum, pageSize);
        QueryWrapper<Log> wrapper = new QueryWrapper<>();

        if (log != null) {
            if (log.getDeviceUid() != null) {
                wrapper.eq("device_uid", log.getDeviceUid());
            }
            if (log.getAction() != null) {
                wrapper.like("action", log.getAction());
            }
        }
        return logMapper.selectPage(page, wrapper);
    }

    @Override
    public boolean createLog(Log log) {
        return logMapper.insert(log) > 0;
    }

    @Override
    public Log getById(Integer id) {
        return logMapper.selectById(id);
    }

    @Override
    public int deleteLogs(List<Integer> ids) {
        return logMapper.deleteBatchIds(ids);
    }
}
