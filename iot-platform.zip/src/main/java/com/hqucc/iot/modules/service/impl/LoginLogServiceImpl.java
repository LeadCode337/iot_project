package com.hqucc.iot.modules.service.impl;

import com.hqucc.iot.modules.entity.LoginLog;
import com.hqucc.iot.modules.mapper.LoginLogMapper;
import com.hqucc.iot.modules.service.LoginLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginLogServiceImpl implements LoginLogService {

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Override
    public boolean save(LoginLog log) {
        return loginLogMapper.insert(log) > 0;
    }
}

