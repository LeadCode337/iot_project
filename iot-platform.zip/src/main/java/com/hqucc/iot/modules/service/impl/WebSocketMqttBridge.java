//package com.example.demo;
//
//import org.eclipse.paho.client.mqttv3.MqttClient;
//import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
//import org.eclipse.paho.client.mqttv3.MqttException;
//import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
//
//import java.io.IOException;
//import java.net.InetSocketAddress;
//import java.nio.ByteBuffer;
//import java.nio.channels.*;
//import java.nio.charset.StandardCharsets;
//import java.security.MessageDigest;
//import java.security.NoSuchAlgorithmException;
//import java.util.Base64;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Map;
//import java.util.Set;
//import java.util.concurrent.CountDownLatch;
//
//
//
//public class WebSocketMqttBridge {
//
//    // MQTT相关配置
//    private final String mqttBroker = "tcp://120.53.223.19:1883";
//    private final String clientId = "WebSocket-MQTT-Bridge-" + System.currentTimeMillis();
//    private MqttClient mqttClient;
//
//    // WebSocket配置
//    private final int webSocketPort = 8080;
//
//    // 要订阅的MQTT主题
//    private final String[] mqttTopics = {"#"}; // 订阅所有主题
//    private final int[] qosLevels = {1}; // QoS级别
//
//    private Selector selector;
//    private ServerSocketChannel serverSocketChannel;
//    private final Map<SocketChannel, WebSocketSession> sessions = new HashMap<>();
//    private Thread serverThread;
//    private volatile boolean isRunning = false;
//
//    // 测试启动WebSocket-MQTT桥接服务
//    @Test
//    public void testWebSocketMqttBridge() throws InterruptedException, IOException, MqttException {
//        System.out.println("Starting WebSocket-MQTT bridge test...");
//
//        // 初始化并启动服务
//        initServer();
//        startServer();
//
//        // 等待服务启动
//        Thread.sleep(2000);
//        System.out.println("WebSocket-MQTT bridge is running. Press Ctrl+C to stop.");
//
//        // 使用CountDownLatch保持测试运行
//        CountDownLatch latch = new CountDownLatch(1);
//        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
//            try {
//                stopServer();
//                latch.countDown();
//            } catch (IOException | MqttException e) {
//                e.printStackTrace();
//            }
//        }));
//
//        // 阻塞直到程序被终止
//        latch.await();
//    }
//
//    private void initServer() throws IOException, MqttException {
//        // 初始化WebSocket服务器
//        this.selector = Selector.open();
//        this.serverSocketChannel = ServerSocketChannel.open();
//        this.serverSocketChannel.bind(new InetSocketAddress(webSocketPort));
//        this.serverSocketChannel.configureBlocking(false);
//        this.serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
//
//        // 初始化MQTT客户端
//        initMqttClient();
//    }
//
//    private void initMqttClient() throws MqttException {
//        MemoryPersistence persistence = new MemoryPersistence();
//        mqttClient = new MqttClient(mqttBroker, clientId, persistence);
//
//        MqttConnectOptions connOpts = new MqttConnectOptions();
//        connOpts.setCleanSession(true);
//        // 如果MQTT服务器需要认证，可以添加以下配置
//        // connOpts.setUserName("username");
//        // connOpts.setPassword("password".toCharArray());
//
//        System.out.println("Connecting to MQTT broker: " + mqttBroker);
//        mqttClient.connect(connOpts);
//        System.out.println("Connected to MQTT broker");
//
//        // 设置MQTT消息回调
//        mqttClient.setCallback(new org.eclipse.paho.client.mqttv3.MqttCallback() {
//            @Override
//            public void connectionLost(Throwable cause) {
//                System.err.println("MQTT connection lost: " + cause.getMessage());
//                // 尝试重连
//                new Thread(() -> {
//                    while (isRunning) {
//                        try {
//                            Thread.sleep(5000);
//                            if (!mqttClient.isConnected()) {
//                                System.out.println("Reconnecting to MQTT broker...");
//                                mqttClient.reconnect();
//                                System.out.println("Reconnected to MQTT broker");
//                                // 重新订阅主题
//                                mqttClient.subscribe(mqttTopics, qosLevels);
//                                break;
//                            }
//                        } catch (Exception e) {
//                            System.err.println("Reconnection failed: " + e.getMessage());
//                        }
//                    }
//                }).start();
//            }
//
//            @Override
//            public void messageArrived(String topic, org.eclipse.paho.client.mqttv3.MqttMessage message) throws Exception {
//                String content = new String(message.getPayload(), StandardCharsets.UTF_8);
//                System.out.println("MQTT message arrived - Topic: " + topic + ", Content: " + content);
//
//                // 构建包含主题和内容的JSON消息
//                String jsonMessage = String.format("{\"topic\":\"%s\", \"message\":\"%s\"}",
//                        escapeJson(topic), escapeJson(content));
//
//                // 将MQTT消息转发给所有连接的WebSocket客户端
//                broadcast(jsonMessage);
//            }
//
//            @Override
//            public void deliveryComplete(org.eclipse.paho.client.mqttv3.IMqttDeliveryToken token) {
//                // 消息发送完成回调
//            }
//        });
//
//        // 订阅MQTT主题
//        mqttClient.subscribe(mqttTopics, qosLevels);
//        System.out.println("Subscribed to MQTT topics: " + String.join(", ", mqttTopics));
//    }
//
//    // 转义JSON特殊字符
//    private String escapeJson(String value) {
//        if (value == null) return "";
//        return value.replace("\\", "\\\\")
//                .replace("\"", "\\\"")
//                .replace("\b", "\\b")
//                .replace("\f", "\\f")
//                .replace("\n", "\\n")
//                .replace("\r", "\\r")
//                .replace("\t", "\\t");
//    }
//
//    private void startServer() {
//        isRunning = true;
//        serverThread = new Thread(this::runServer);
//        serverThread.start();
//        System.out.println("WebSocket server started on port: " + webSocketPort);
//    }
//
//    private void runServer() {
//        try {
//            while (isRunning) {
//                selector.select(1000); // 超时1秒，允许定期检查isRunning状态
//                Set<SelectionKey> selectedKeys = selector.selectedKeys();
//                Iterator<SelectionKey> iterator = selectedKeys.iterator();
//
//                while (iterator.hasNext()) {
//                    SelectionKey key = iterator.next();
//                    iterator.remove();
//
//                    try {
//                        if (key.isAcceptable()) {
//                            handleAccept(key);
//                        } else if (key.isReadable()) {
//                            handleRead(key);
//                        }
//                    } catch (IOException e) {
//                        handleError(key, e);
//                        key.cancel();
//                    }
//                }
//            }
//        } catch (IOException e) {
//            System.err.println("Server error: " + e.getMessage());
//        }
//    }
//
//    private void handleAccept(SelectionKey key) throws IOException {
//        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
//        SocketChannel clientChannel = serverChannel.accept();
//        clientChannel.configureBlocking(false);
//        clientChannel.register(selector, SelectionKey.OP_READ);
//
//        // 创建新的会话
//        WebSocketSession session = new WebSocketSession(clientChannel);
//        sessions.put(clientChannel, session);
//
//        System.out.println("New WebSocket client connected: " + clientChannel.getRemoteAddress());
//    }
//
//    private void handleRead(SelectionKey key) throws IOException {
//        SocketChannel clientChannel = (SocketChannel) key.channel();
//        WebSocketSession session = sessions.get(clientChannel);
//
//        if (session == null) {
//            key.cancel();
//            return;
//        }
//
//        ByteBuffer buffer = ByteBuffer.allocate(1024);
//        int bytesRead = clientChannel.read(buffer);
//
//        if (bytesRead == -1) {
//            // 客户端断开连接
//            closeSession(session);
//            key.cancel();
//            return;
//        }
//
//        buffer.flip();
//
//        // 如果还未完成握手
//        if (!session.isHandshaked()) {
//            handleHandshake(session, buffer);
//        } else {
//            // 处理WebSocket消息
//            handleWebSocketFrame(session, buffer);
//        }
//    }
//
//    private void handleHandshake(WebSocketSession session, ByteBuffer buffer) throws IOException {
//        // 将字节转换为字符串
//        String request = StandardCharsets.UTF_8.decode(buffer).toString();
//
//        // 检查是否是WebSocket升级请求
//        if (request.contains("Upgrade: websocket") && request.contains("Connection: Upgrade")) {
//            // 提取Sec-WebSocket-Key
//            String key = extractWebSocketKey(request);
//            if (key != null) {
//                // 生成响应密钥
//                String acceptKey = generateAcceptKey(key);
//
//                // 构建握手响应
//                String response = "HTTP/1.1 101 Switching Protocols\r\n" +
//                        "Upgrade: websocket\r\n" +
//                        "Connection: Upgrade\r\n" +
//                        "Sec-WebSocket-Accept: " + acceptKey + "\r\n\r\n";
//
//                // 发送响应
//                ByteBuffer responseBuffer = ByteBuffer.wrap(response.getBytes(StandardCharsets.UTF_8));
//                session.getChannel().write(responseBuffer);
//
//                // 标记握手完成
//                session.setHandshaked(true);
//
//                System.out.println("WebSocket handshake completed");
//                session.send("Connected to Spring Boot WebSocket-MQTT bridge. Listening to MQTT broker: " + mqttBroker);
//            }
//        }
//    }
//
//    private void handleWebSocketFrame(WebSocketSession session, ByteBuffer buffer) throws IOException {
//        while (buffer.hasRemaining()) {
//            // 解析WebSocket帧
//            if (session.getFrameBuffer().remaining() == 0) {
//                // 读取帧头
//                if (buffer.remaining() < 2) {
//                    // 不够读取帧头，保存剩余数据
//                    session.getFrameBuffer().put(buffer);
//                    return;
//                }
//
//                byte firstByte = buffer.get();
//                byte secondByte = buffer.get();
//
//                // 解析FIN和操作码
//                boolean fin = (firstByte & 0x80) != 0;
//                int opcode = firstByte & 0x0F;
//
//                // 解析掩码和 payload 长度
//                boolean masked = (secondByte & 0x80) != 0;
//                int payloadLength = secondByte & 0x7F;
//
//                // 处理不同的 payload 长度
//                if (payloadLength == 126) {
//                    if (buffer.remaining() < 2) {
//                        // 回退已读取的字节
//                        buffer.position(buffer.position() - 2);
//                        session.getFrameBuffer().put(buffer);
//                        return;
//                    }
//                    payloadLength = (buffer.get() & 0xFF) << 8 | (buffer.get() & 0xFF);
//                } else if (payloadLength == 127) {
//                    if (buffer.remaining() < 8) {
//                        // 回退已读取的字节
//                        buffer.position(buffer.position() - 2);
//                        session.getFrameBuffer().put(buffer);
//                        return;
//                    }
//                    // 简化处理，实际应该处理64位长度
//                    payloadLength = 0;
//                    for (int i = 0; i < 8; i++) {
//                        payloadLength = (payloadLength << 8) | (buffer.get() & 0xFF);
//                    }
//                }
//
//                // 读取掩码密钥
//                byte[] mask = new byte[4];
//                if (masked) {
//                    if (buffer.remaining() < 4) {
//                        // 回退已读取的字节
//                        buffer.position(buffer.position() - (payloadLength == 126 ? 2 : payloadLength == 127 ? 8 : 0) - 2);
//                        session.getFrameBuffer().put(buffer);
//                        return;
//                    }
//                    buffer.get(mask);
//                }
//
//                // 读取 payload 数据
//                if (buffer.remaining() < payloadLength) {
//                    // 回退已读取的字节
//                    int bytesRead = 2 + (payloadLength == 126 ? 2 : payloadLength == 127 ? 8 : 0) + (masked ? 4 : 0);
//                    buffer.position(buffer.position() - bytesRead);
//
//                    // 保存到帧缓冲区
//                    session.getFrameBuffer().put(buffer);
//                    session.setFrameInfo(fin, opcode, payloadLength, masked, mask);
//                    return;
//                }
//
//                // 处理 payload
//                byte[] payload = new byte[payloadLength];
//                buffer.get(payload);
//
//                // 如果有掩码，解码
//                if (masked) {
//                    for (int i = 0; i < payloadLength; i++) {
//                        payload[i] ^= mask[i % 4];
//                    }
//                }
//
//                // 处理文本消息
//                if (opcode == 0x01) { // 文本帧
//                    String message = new String(payload, StandardCharsets.UTF_8);
//                    System.out.println("Received from WebSocket client: " + message);
//                    // 可以在这里处理从客户端收到的消息
//                } else if (opcode == 0x08) { // 关闭帧
//                    closeSession(session);
//                    return;
//                }
//            } else {
//                // 处理不完整的帧
//                // 实际应用中应该完善这部分逻辑
//            }
//        }
//    }
//
//    private String extractWebSocketKey(String request) {
//        String[] lines = request.split("\r\n");
//        for (String line : lines) {
//            if (line.startsWith("Sec-WebSocket-Key:")) {
//                return line.substring("Sec-WebSocket-Key:".length()).trim();
//            }
//        }
//        return null;
//    }
//
//    private String generateAcceptKey(String key) {
//        try {
//            String magicString = key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
//            MessageDigest md = MessageDigest.getInstance("SHA-1");
//            byte[] hash = md.digest(magicString.getBytes(StandardCharsets.UTF_8));
//            return Base64.getEncoder().encodeToString(hash);
//        } catch (NoSuchAlgorithmException e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//    // 向所有连接的客户端广播消息
//    public void broadcast(String message) {
//        for (WebSocketSession session : sessions.values()) {
//            try {
//                if (session.isHandshaked()) {
//                    session.send(message);
//                }
//            } catch (IOException e) {
//                System.err.println("Failed to send message to client: " + e.getMessage());
//                try {
//                    closeSession(session);
//                } catch (IOException ex) {
//                    // 忽略关闭错误
//                }
//            }
//        }
//    }
//
//    private void closeSession(WebSocketSession session) throws IOException {
//        SocketChannel channel = session.getChannel();
//        sessions.remove(channel);
//        channel.close();
//
//        System.out.println("WebSocket client disconnected: " + channel.getRemoteAddress());
//    }
//
//    private void handleError(SelectionKey key, IOException e) {
//        SocketChannel channel = (SocketChannel) key.channel();
//        WebSocketSession session = sessions.get(channel);
//
//        System.err.println("Error occurred: " + e.getMessage());
//
//        if (session != null) {
//            try {
//                closeSession(session);
//            } catch (IOException ex) {
//                // 忽略关闭错误
//            }
//        }
//    }
//
//    private void stopServer() throws IOException, MqttException {
//        isRunning = false;
//
//        // 关闭MQTT连接
//        if (mqttClient != null && mqttClient.isConnected()) {
//            mqttClient.disconnect();
//            mqttClient.close();
//            System.out.println("MQTT connection closed");
//        }
//
//        // 关闭所有WebSocket连接
//        for (WebSocketSession session : sessions.values()) {
//            try {
//                session.close();
//            } catch (IOException e) {
//                // 忽略关闭错误
//            }
//        }
//        sessions.clear();
//
//        // 关闭服务器通道和选择器
//        if (serverSocketChannel != null) {
//            serverSocketChannel.close();
//        }
//        if (selector != null) {
//            selector.close();
//        }
//
//        // 等待服务器线程结束
//        if (serverThread != null) {
//            try {
//                serverThread.join(1000);
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//            }
//        }
//
//        System.out.println("WebSocket server stopped");
//    }
//
//    // WebSocket会话类
//    public class WebSocketSession {
//        private final SocketChannel channel;
//        private boolean handshaked = false;
//        private final ByteBuffer frameBuffer = ByteBuffer.allocate(4096);
//        private boolean fin;
//        private int opcode;
//        private int payloadLength;
//        private boolean masked;
//        private byte[] mask;
//
//        public WebSocketSession(SocketChannel channel) {
//            this.channel = channel;
//        }
//
//        public SocketChannel getChannel() {
//            return channel;
//        }
//
//        public boolean isHandshaked() {
//            return handshaked;
//        }
//
//        public void setHandshaked(boolean handshaked) {
//            this.handshaked = handshaked;
//        }
//
//        public ByteBuffer getFrameBuffer() {
//            return frameBuffer;
//        }
//
//        public void setFrameInfo(boolean fin, int opcode, int payloadLength, boolean masked, byte[] mask) {
//            this.fin = fin;
//            this.opcode = opcode;
//            this.payloadLength = payloadLength;
//            this.masked = masked;
//            this.mask = mask;
//        }
//
//        // 发送消息
//        public void send(String message) throws IOException {
//            if (!handshaked) {
//                throw new IllegalStateException("WebSocket handshake not completed");
//            }
//
//            byte[] data = message.getBytes(StandardCharsets.UTF_8);
//            int dataLength = data.length;
//
//            // 计算帧头长度
//            int headerLength = 2;
//            if (dataLength <= 125) {
//                // payload 长度用7位表示
//            } else if (dataLength <= 65535) {
//                // payload 长度用16位表示
//                headerLength += 2;
//            } else {
//                // payload 长度用64位表示
//                headerLength += 8;
//            }
//
//            // 分配缓冲区
//            ByteBuffer buffer = ByteBuffer.allocate(headerLength + dataLength);
//
//            // 写入第一个字节: FIN=1, 操作码=文本(0x01)
//            buffer.put((byte) 0x81);
//
//            // 写入第二个字节和长度
//            if (dataLength <= 125) {
//                buffer.put((byte) dataLength);
//            } else if (dataLength <= 65535) {
//                buffer.put((byte) 126);
//                buffer.put((byte) (dataLength >>> 8));
//                buffer.put((byte) (dataLength & 0xFF));
//            } else {
//                buffer.put((byte) 127);
//                buffer.putLong(dataLength);
//            }
//
//            // 写入消息内容
//            buffer.put(data);
//
//            // 发送数据
//            buffer.flip();
//            channel.write(buffer);
//        }
//
//        // 关闭连接
//        public void close() throws IOException {
//            // 发送关闭帧
//            ByteBuffer buffer = ByteBuffer.allocate(2);
//            buffer.put((byte) 0x88); // FIN=1, 操作码=关闭(0x08)
//            buffer.put((byte) 0x00); // 无 payload
//            buffer.flip();
//            channel.write(buffer);
//
//            // 关闭通道
//            channel.close();
//        }
//    }
//}
//