package com.hqucc.iot.modules.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hqucc.iot.modules.dto.MqttAclCreateDTO;
import com.hqucc.iot.modules.entity.MqttAcl;
import com.hqucc.iot.modules.entity.MqttUser;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;

public interface MqttAclMapper extends BaseMapper<MqttAcl> {

    ArrayList<MqttUser> queryInfoByMqttUserName(@Param("mqttAclCreateDTO") MqttAclCreateDTO mqttAclCreateDTO);
}
