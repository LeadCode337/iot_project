package com.hqucc.iot.modules.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class DevicePageDTO {
    private Integer id;
    private Long deviceUid;
    private String name;
    private String macAddress;
    private Integer status;
    private LocalDateTime createdAt;
    private String mqttUsername;
}