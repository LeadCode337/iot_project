package com.hqucc.iot.modules.controller;

import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.dto.MqttPublishDTO;
import com.hqucc.iot.modules.service.DmsMqttGateWayService;
import com.hqucc.iot.modules.service.MqttAclService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/mqtt")
@RequiredArgsConstructor
@Slf4j
public class MqttController {

    private final DmsMqttGateWayService mqttGateWay;
    private final MqttAclService mqttAclService;

    @PostMapping("/publish")
    public CommonResult<String> publish(@Valid @RequestBody MqttPublishDTO dto) {
        if (!mqttAclService.isAllowed(dto.getMqttUsername(), dto.getTopic(), "publish")) {
            log.warn("用户 {} 无权限向主题 {} 发布消息", dto.getMqttUsername(), dto.getTopic());
            return CommonResult.failed("无权限向该主题发布消息");
        }

        try {
            mqttGateWay.sendMessageToMqtt(dto.getPayload(), dto.getTopic(), dto.getQos());
            log.info("用户 {} 成功向 {} 发布消息", dto.getMqttUsername(), dto.getTopic());
            return CommonResult.success(null, "发布成功");
        } catch (Exception e) {
            log.error("发布失败", e);
            return CommonResult.failed("发布失败：" + e.getMessage());
        }
    }
}