package com.hqucc.iot.modules.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.DevicePageDTO;
import com.hqucc.iot.modules.entity.Device;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DeviceMapper extends BaseMapper<Device> {
    IPage<DevicePageDTO> selectDevicePageDTO(Page<DevicePageDTO> page, @Param("name") String name, @Param("macAddress") String macAddress, @Param("status") Integer status, @Param("mqttUidList") List<Long> mqttUidList);

    Device selectDeviceByName(@Param("name") Integer id);
}
