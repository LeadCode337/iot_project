package com.hqucc.iot.modules.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MqttPublishDTO {
    @NotBlank(message = "mqtt用户不能为空")
    private String mqttUsername;

    @NotBlank(message = "主题不能为空")
    private String topic;

    @NotBlank(message = "消息内容不能为空")
    private String payload;

    private Integer qos = 1; // 默认 QoS 等级
}
