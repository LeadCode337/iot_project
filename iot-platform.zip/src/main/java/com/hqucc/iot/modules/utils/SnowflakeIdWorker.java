package com.hqucc.iot.modules.utils;

public class SnowflakeIdWorker {
    // 开源算法中的常量，如基准时间戳、机器ID、数据中心ID
    private static final long START_STAMP = 1609459200000L; // 2021-01-01, 示例
    private static final long SEQUENCE_BIT = 12;
    private static final long MACHINE_BIT  = 5;
    private static final long DATACENTER_BIT = 5;

    private static final long MAX_DATACENTER_NUM = ~(-1L << DATACENTER_BIT);
    private static final long MAX_MACHINE_NUM    = ~(-1L << MACHINE_BIT);
    private static final long MAX_SEQUENCE       = ~(-1L << SEQUENCE_BIT);

    private static final long MACHINE_LEFT      = SEQUENCE_BIT;
    private static final long DATACENTER_LEFT   = SEQUENCE_BIT + MACHINE_BIT;
    private static final long TIMESTAMP_LEFT    = SEQUENCE_BIT + MACHINE_BIT + DATACENTER_BIT;

    private long datacenterId;  // 数据中心ID
    private long machineId;     // 机器ID
    private long sequence = 0L; // 序列号
    private long lastStamp = -1L;// 上一次时间戳

    public SnowflakeIdWorker(long datacenterId, long machineId) {
        if (datacenterId > MAX_DATACENTER_NUM || datacenterId < 0) {
            throw new IllegalArgumentException("datacenterId error");
        }
        if (machineId > MAX_MACHINE_NUM || machineId < 0) {
            throw new IllegalArgumentException("machineId error");
        }
        this.datacenterId = datacenterId;
        this.machineId = machineId;
    }

    // 线程安全获取下一个ID
    public synchronized long nextId() {
        long currStamp = getNewStamp();
        if (currStamp < lastStamp) {
            throw new RuntimeException("Clock moved backwards. Refusing to generate id");
        }

        if (currStamp == lastStamp) {
            sequence = (sequence + 1) & MAX_SEQUENCE;
            if (sequence == 0L) {
                // sequence跑满了, 等待下一毫秒
                currStamp = getNextMill();
            }
        } else {
            sequence = 0L;
        }
        lastStamp = currStamp;

        // 时间戳部分 | 数据中心部分 | 机器标识部分 | 序列号部分
        return (currStamp - START_STAMP) << TIMESTAMP_LEFT
                | datacenterId << DATACENTER_LEFT
                | machineId << MACHINE_LEFT
                | sequence;
    }

    private long getNextMill() {
        long mill = getNewStamp();
        while (mill <= lastStamp) {
            mill = getNewStamp();
        }
        return mill;
    }

    private long getNewStamp() {
        return System.currentTimeMillis();
    }
}

