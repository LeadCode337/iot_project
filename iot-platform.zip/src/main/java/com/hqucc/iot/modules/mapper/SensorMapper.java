package com.hqucc.iot.modules.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.SensorPageDTO;
import com.hqucc.iot.modules.entity.Sensor;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SensorMapper extends BaseMapper<Sensor> {
    IPage<SensorPageDTO> selectSensorPageDTO(Page<SensorPageDTO> page,
                                             @Param("sensorType") String sensorType,
                                             @Param("deviceUid") Long deviceUid,
                                             @Param("visibleDeviceUids") List<Long> visibleDeviceUids);
}
