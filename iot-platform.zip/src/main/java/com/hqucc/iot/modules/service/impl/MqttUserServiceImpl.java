package com.hqucc.iot.modules.service.impl;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.crypto.SecureUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.entity.Device;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.Sensor;
import com.hqucc.iot.modules.entity.SensorData;
import com.hqucc.iot.modules.mapper.DeviceMapper;
import com.hqucc.iot.modules.mapper.MqttUserMapper;
import com.hqucc.iot.modules.mapper.SensorDataMapper;
import com.hqucc.iot.modules.mapper.SensorMapper;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.utils.SnowflakeIdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class MqttUserServiceImpl implements MqttUserService {

    @Autowired
    private MqttUserMapper mqttUserMapper;

    @Autowired
    private DeviceMapper deviceMapper;


    @Autowired
    private SensorMapper sensorMapper;


    @Autowired
    private SensorDataMapper sensorDataMapper;

    private static SnowflakeIdWorker idWorker = new SnowflakeIdWorker(1, 1);

    @Override
    public Page<MqttUser> list(MqttUser mqttUser, Integer pageSize, Integer pageNum) {
        Page<MqttUser> page = new Page<>(pageNum, pageSize);
        QueryWrapper<MqttUser> wrapper = new QueryWrapper<>();
        if (mqttUser != null) {
            if (mqttUser.getOwnerUid() != null) {
                wrapper.eq("owner_uid", mqttUser.getOwnerUid());
            }

            if (mqttUser.getUsername() != null) {
                wrapper.like("username", mqttUser.getUsername());
            }
        }
        return mqttUserMapper.selectPage(page, wrapper);
    }

    @Override
    public Page<MqttUser> listByOwner(Long ownerUid, Integer pageSize, Integer pageNum) {
        Page<MqttUser> page = new Page<>(pageNum, pageSize);
        QueryWrapper<MqttUser> wrapper = new QueryWrapper<>();
        if (ownerUid != null) {
            wrapper.eq("owner_uid", ownerUid);
        }
        return mqttUserMapper.selectPage(page, wrapper);
    }


    @Override
    public MqttUser getById(Integer id) {
        return mqttUserMapper.selectById(id);
    }

    @Override
    public boolean createUser(MqttUser mqttUser, String password) {
        if (mqttUser.getUsername() == null || password == null) {
            throw new IllegalArgumentException("用户名和密码不能为空");
        }

        String salt = RandomUtil.randomString(8);

        String hashed = SecureUtil.md5(password + salt);

        if (mqttUser.getMqttUid() == null) {
            long newUid = idWorker.nextId();
            mqttUser.setMqttUid(newUid);
        }

        mqttUser.setPasswordHash(hashed);
        mqttUser.setPlainPassword(password);
        mqttUser.setSalt(salt);
        mqttUser.setCreated(LocalDateTime.now());
        mqttUser.setIsSuperUser(false);

        return mqttUserMapper.insert(mqttUser) > 0;
    }

    @Override
    public boolean updateUser(MqttUser mqttUser) {
        return mqttUserMapper.updateById(mqttUser) > 0;
    }

    @Override
    public boolean updatePasswordById(Integer id, String newPassword) {
        MqttUser user = mqttUserMapper.selectById(id);
        if (user == null) {
            throw new IllegalArgumentException("用户不存在");
        }

        // 生成新盐
        String salt = RandomUtil.randomString(8);

        // 加密密码：md5(password + salt)
        String passwordHash = SecureUtil.md5(newPassword + salt);

        // 更新字段
        user.setSalt(salt);
        user.setPasswordHash(passwordHash);

        return mqttUserMapper.updateById(user) > 0;
    }

    @Override
    public List<MqttUser> listByOwnerUid(Long ownerUid) {
        QueryWrapper<MqttUser> wrapper = new QueryWrapper<>();
        wrapper.eq("owner_uid", ownerUid);
        return mqttUserMapper.selectList(wrapper);
    }


    @Override
    public List<MqttUser> listAllNormalUsers() {
        return mqttUserMapper.selectList(
                new QueryWrapper<MqttUser>()
                        .eq("is_superuser", false)   // 只取普通用户
        );
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int deleteMqttUserById(List<Integer> ids) {
        if (ids == null || ids.isEmpty()) {
            return 0;
        }
        int totalDeleted = 0;
        for (Integer id : ids) {
            MqttUser user = mqttUserMapper.selectById(id);
            if (user == null || user.getMqttUid() == null) {
                continue;
            }

            Long mqttUid = user.getMqttUid();
            List<Device> deviceList = deviceMapper.selectList(
                    new QueryWrapper<Device>().eq("mqtt_uid", mqttUid)
            );

            if (!deviceList.isEmpty()) {
                List<Long> deviceUids = deviceList.stream()
                        .map(Device::getDeviceUid)
                        .collect(Collectors.toList());
                List<Long> sensorUids = sensorMapper.selectList(
                        new QueryWrapper<Sensor>().in("device_uid", deviceUids)
                ).stream().map(Sensor::getSensorUid).collect(Collectors.toList());
                if (!sensorUids.isEmpty()) {
                    sensorDataMapper.delete(new QueryWrapper<SensorData>().in("sensor_uid", sensorUids));
                }
                sensorMapper.delete(new QueryWrapper<Sensor>().in("device_uid", deviceUids));
                deviceMapper.delete(new QueryWrapper<Device>().in("device_uid", deviceUids));
            }
            totalDeleted += mqttUserMapper.deleteById(id);
        }

        return totalDeleted;
    }

    @Override
    public MqttUser getByUsername(String username) {
        QueryWrapper<MqttUser> wrapper = new QueryWrapper<>();
        wrapper.eq("username", username);
        return mqttUserMapper.selectOne(wrapper);
    }

}