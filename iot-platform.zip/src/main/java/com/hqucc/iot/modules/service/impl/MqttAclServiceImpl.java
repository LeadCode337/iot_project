package com.hqucc.iot.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hqucc.iot.modules.dto.MqttAclCreateDTO;
import com.hqucc.iot.modules.dto.MqttAclQueryDTO;
import com.hqucc.iot.modules.entity.MqttAcl;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.User;
import com.hqucc.iot.modules.mapper.MqttAclMapper;
import com.hqucc.iot.modules.service.MqttAclService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import com.hqucc.iot.modules.vo.MqttCol;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MqttAclServiceImpl extends ServiceImpl<MqttAclMapper, MqttAcl> implements MqttAclService {

    @Autowired
    private MqttUserService mqttUserService;
    @Autowired
    private MqttAclMapper mqttAclMapper;

    @Override
    public List<String> getSubscribableTopicsByUsername(String username) {
        return this.baseMapper.selectList(
                        new QueryWrapper<MqttAcl>()
                                .eq("username", username)
                                .eq("action", "subscribe")
                ).stream()
                .map(MqttAcl::getTopic)
                .distinct()
                .collect(Collectors.toList());
    }

    @Override
    public boolean isAllowed(String username, String topic, String action) {
        // 支持 topic 模糊匹配（类似 iot/+/device/#）
        List<MqttAcl> rules = this.list(new QueryWrapper<MqttAcl>()
                .eq("username", username)
                .eq("action", action)
                .eq("permission", "allow"));

        return rules.stream().anyMatch(acl -> topicMatches(acl.getTopic(), topic));
    }

    @Override
    public MqttAcl getByUid(Integer id) {
        if (id == null) return null;
        QueryWrapper<MqttAcl> wrapper = new QueryWrapper<>();
        wrapper.eq("id", id).last("limit 1");
        return mqttAclMapper.selectOne(wrapper);
    }

    @Override
    public boolean editMqttAcl(MqttAcl dto) {

        if (dto == null || dto.getId() == null) {
            return false;
        }

        MqttAcl byUid = getByUid(dto.getId());
        if (byUid == null) {
            return false;
        }
        dto.setId(byUid.getId());
        return mqttAclMapper.updateById(dto) > 0;


    }

    private boolean topicMatches(String aclTopic, String realTopic) {
        String[] aclLevels = aclTopic.split("/");
        String[] topicLevels = realTopic.split("/");

        for (int i = 0; i < aclLevels.length; i++) {
            if (i >= topicLevels.length) return false;
            if (aclLevels[i].equals("#")) return true;
            if (aclLevels[i].equals("+")) continue;
            if (!aclLevels[i].equals(topicLevels[i])) return false;
        }
        return aclLevels.length == topicLevels.length;
    }

    @Override
    public Page<MqttAcl> list(MqttAclQueryDTO query, Integer pageSize, Integer pageNum) {
        Page<MqttAcl> page = new Page<>(pageNum, pageSize);
        QueryWrapper<MqttAcl> wrapper = new QueryWrapper<>();

        if (query.getUsername() != null) {
            wrapper.like("username", query.getUsername());
        }

        if (query.getTopic() != null) {
            wrapper.like("topic", query.getTopic());
        }

        if (query.getAction() != null) {
            wrapper.eq("action", query.getAction());
        }

        if (query.getMqttUidList() != null && !query.getMqttUidList().isEmpty()) {
            wrapper.in("mqtt_uid", query.getMqttUidList());
        }

        wrapper.orderByAsc("id");

        return this.page(page, wrapper);
    }

    @Override
    public boolean createMqttAcl(MqttAclCreateDTO dto) {

        MqttAcl acl = new MqttAcl();
        BeanUtils.copyProperties(dto, acl);
        if (acl.getQos() == null) {
            acl.setQos(1);
        }
        if (acl.getRetain() == null) {
            acl.setRetain(0);
        }

        ArrayList<MqttUser> mqttUsers = mqttAclMapper.queryInfoByMqttUserName(dto);

        System.out.println("查询到的mqttUsers"+mqttUsers);

        if (mqttUsers == null || mqttUsers.isEmpty()) {
            throw new RuntimeException("当前用户未绑定 MQTT 账号，无法添加 ACL");
        }

        // 默认使用第一个 mqtt_user 的 uid
        acl.setMqttUid(mqttUsers.get(0).getMqttUid());
        acl.setCreatedAt(LocalDateTime.now());

        return this.save(acl);
    }
}