package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.hqucc.iot.modules.dto.SensorPageDTO;
import com.hqucc.iot.modules.entity.Sensor;

import java.util.List;

public interface SensorService {
    IPage<SensorPageDTO> list(Sensor sensor, Integer pageSize, Integer pageNum, List<Long> visibleDeviceUids);
    Sensor getBySensorUid(Long sensorUid);
    boolean createSensor(Sensor sensor);
    boolean updateSensor(Sensor sensor);
    Sensor getByDeviceUidAndType(Long deviceUid, String sensorType);
    Sensor getById(Integer id);
    int deleteSensors(List<Integer> ids);
    List<Long> getSensorUidsByDeviceUids(List<Long> deviceUids);
}