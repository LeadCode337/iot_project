package com.hqucc.iot.modules.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SensorDataPageDTO {
    private Integer id;
    private Long sensorUid;
    private String readingType;
    private String readingValue;
    private LocalDateTime createdAt;

    private String sensorType;
    private Long deviceUid;
    private String deviceName;
    private String mqttUsername;
}