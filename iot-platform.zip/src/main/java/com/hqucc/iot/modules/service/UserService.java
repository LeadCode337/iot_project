package com.hqucc.iot.modules.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.RegisterRequestDTO;
import com.hqucc.iot.modules.entity.User;

import java.util.List;

public interface UserService {

    Page<User> list(User user, Integer pageSize, Integer pageNum);

    User getUserByUsername(String username);

    User getById(Integer id);

    int deleteUsers(List<Integer> ids);

    User getByUid(Long uid);

    boolean createUser(User user);

    boolean updateUser(User user);

    boolean validateUser(String username, String password);

    int deleteUsersByUid(List<Long> userUids);


    boolean updateUserProfile(User user);

    boolean updateUserAvatar(Long uid, String avatarUrl);

    boolean updateUserPassword(User user);

    int batchCreateUsers(List<RegisterRequestDTO> users);

}
