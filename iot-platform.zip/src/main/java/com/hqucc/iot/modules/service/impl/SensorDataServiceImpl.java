package com.hqucc.iot.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.SensorDataPageDTO;
import com.hqucc.iot.modules.entity.SensorData;
import com.hqucc.iot.modules.mapper.SensorDataMapper;
import com.hqucc.iot.modules.service.DeviceService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.service.SensorDataService;
import com.hqucc.iot.modules.service.SensorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SensorDataServiceImpl implements SensorDataService {

    @Autowired
    private SensorDataMapper sensorDataMapper;

    @Override
    public Page<SensorDataPageDTO> list(SensorData query, Integer pageSize, Integer pageNum, List<Long> visibleSensorUids) {
        Page<SensorDataPageDTO> page = new Page<>(pageNum, pageSize);
        String type = query != null ? query.getReadingType() : null;
        return sensorDataMapper.selectPageWithJoin(page, visibleSensorUids, type);
    }

    @Override
    public SensorData getBySensorUid(Long sensorUid) {
        QueryWrapper<SensorData> wrapper = new QueryWrapper<>();
        wrapper.eq("sensor_uid", sensorUid).last("limit 1");
        return sensorDataMapper.selectOne(wrapper);
    }

    @Override
    public boolean createData(SensorData data) {
        return sensorDataMapper.insert(data) > 0;
    }

    @Override
    public List<SensorData> getByTimeRange(Long sensorUid, String startTime, String endTime) {
        QueryWrapper<SensorData> wrapper = new QueryWrapper<>();
        wrapper.eq("sensor_uid", sensorUid)
                .between("created_at", startTime, endTime)
                .orderByAsc("created_at");
        return sensorDataMapper.selectList(wrapper);
    }

    @Override
    public SensorData getLatestBySensorUidAndType(Long sensorUid, String readingType) {
        QueryWrapper<SensorData> wrapper = new QueryWrapper<>();
        wrapper.eq("sensor_uid", sensorUid)
                .eq("reading_type", readingType)
                .orderByDesc("created_at")
                .last("limit 1");
        return sensorDataMapper.selectOne(wrapper);
    }

    @Override
    public boolean insertSensorData(SensorData data) {
        return sensorDataMapper.insert(data) > 0;
    }

    @Override
    public boolean updateSensorData(SensorData data) {
        return sensorDataMapper.updateById(data) > 0;
    }

    @Override
    public SensorData getByDataId(Integer id) {
        return sensorDataMapper.selectById(id);
    }

    @Override
    public int deleteDataById(List<Integer> ids) {
        if (ids == null || ids.isEmpty()) {
            throw new IllegalArgumentException("ID列表不能为空");
        }
        return sensorDataMapper.deleteBatchIds(ids);
    }
}