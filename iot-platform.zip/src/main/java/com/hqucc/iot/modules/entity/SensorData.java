package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("sensor_data")
public class SensorData {

  @TableId
  private Integer id;

  @TableField("sensor_uid")
  private Long sensorUid;

  @TableField("reading_type")
  private String readingType;

  @TableField("reading_value")
  private String readingValue;

  @TableField("created_at")
  private LocalDateTime createdAt;
}