package com.hqucc.iot.modules.dto;

import lombok.Data;
import java.util.List;

@Data
public class MqttPayload {
    private String mac;
    private String deviceName;
    private Long timestamp;             // 用于去重或记录消息时间
    private List<MqttReading> readings; // 每条读数(传感器类型 + 值)
}