package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.dto.MqttAclCreateDTO;
import com.hqucc.iot.modules.dto.MqttAclQueryDTO;
import com.hqucc.iot.modules.dto.MqttAclUpdateDTO;
import com.hqucc.iot.modules.entity.MqttAcl;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.User;
import com.hqucc.iot.modules.service.MqttAclService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import com.hqucc.iot.modules.vo.MqttCol;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Api(tags = "MQTT ACL 管理")
@RestController
@RequestMapping("/api/mqtt-acl")
public class MqttAclController {

    @Autowired
    private MqttAclService mqttAclService;
    @Autowired
    private MqttUserService mqttUserService;

    @ApiOperation("分页查询 MQTT ACL")
    @GetMapping("/list")
    public CommonResult<CommonPage<MqttAcl>> list(
            MqttAclQueryDTO query,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "1") Integer pageNum
    ) {
        // 获取当前系统用户 uid 和角色
        Long ownerUid = CurrentUserUtils.getUid();
        String role = CurrentUserUtils.getRole();

        // 普通用户过滤其所有 mqtt_uid 对应的设备
        if ("user".equals(role)) {
            List<MqttUser> mqttUsers = mqttUserService.listByOwnerUid(ownerUid);
            List<Long> mqttUids = mqttUsers.stream()
                    .map(MqttUser::getMqttUid)
                    .collect(Collectors.toList());

            if (mqttUids.isEmpty()) {
                // 无任何 MQTT 账号，返回空
                return CommonResult.success(CommonPage.restPage(new Page<>()));
            }
            // 放入 device 对象供 service 层处理
            query.setMqttUidList(mqttUids); // ✨ 你需要在 Device 实体中添加 List<Long> mqttUidList 字段
        }
        Page<MqttAcl> mqttAclPage = mqttAclService.list(query, pageSize, pageNum);
        return CommonResult.success(CommonPage.restPage(mqttAclPage));
    }

    @ApiOperation("新增 MQTT ACL")
    @PostMapping("/create")
    public CommonResult<Boolean> create(@Valid @RequestBody MqttAclCreateDTO dto) {
        boolean success = mqttAclService.createMqttAcl(dto);
        return success ? CommonResult.success(true, "创建成功") : CommonResult.failed("创建失败");
    }


    @ApiOperation("修改 MQTT ACL")
    @PostMapping("/edit")
    public CommonResult<Boolean> edit(@Valid @RequestBody MqttCol dto) {

        MqttAcl byUid = mqttAclService.getByUid(dto.getId());

        if (byUid == null) return CommonResult.failed("信息不存在");

        byUid.setAction(dto.getAction());
        byUid.setPermission(dto.getPermission());
        byUid.setUsername(dto.getUsername());
        byUid.setTopic(dto.getTopic());


        return mqttAclService.editMqttAcl(byUid) ? CommonResult.success(true, "资料更新成功") : CommonResult.failed("资料更新失败");
    }

    @ApiOperation("更新 MQTT ACL")
    @PostMapping("/update")
    public CommonResult<Boolean> update(@Valid @RequestBody MqttAclUpdateDTO dto) {
        MqttAcl acl = mqttAclService.getById(dto.getId());
        if (acl == null) {
            return CommonResult.failed("记录不存在");
        }
        BeanUtils.copyProperties(dto, acl);
        boolean success = mqttAclService.updateById(acl);
        return success ? CommonResult.success(true, "更新成功") : CommonResult.failed("更新失败");
    }

    @ApiOperation("删除 MQTT ACL")
    @PostMapping("/delete")
    public CommonResult<Boolean> delete(@RequestParam Integer id) {
        return mqttAclService.removeById(id)
                ? CommonResult.success(true, "删除成功")
                : CommonResult.failed("删除失败");
    }

    @ApiOperation("批量删除 MQTT ACL")
    @PostMapping("/delete-batch")
    public CommonResult<Integer> deleteBatch(@RequestBody List<Integer> ids) {
        boolean success = mqttAclService.removeByIds(ids);
        return success ? CommonResult.success(ids.size(), "成功删除 " + ids.size() + " 条记录") : CommonResult.failed("批量删除失败");
    }
}