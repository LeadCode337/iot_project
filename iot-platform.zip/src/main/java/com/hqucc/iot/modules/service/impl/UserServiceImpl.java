package com.hqucc.iot.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.xiaoymin.knife4j.core.util.StrUtil;
import com.hqucc.iot.modules.dto.RegisterRequestDTO;
import com.hqucc.iot.modules.entity.User;
import com.hqucc.iot.modules.mapper.UserMapper;
import com.hqucc.iot.modules.service.UserService;
import com.hqucc.iot.modules.utils.SnowflakeIdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    private static SnowflakeIdWorker idWorker = new SnowflakeIdWorker(1, 1);

    @Override
    public Page<User> list(User user, Integer pageSize, Integer pageNum) {
        Page<User> page = new Page<>(pageNum, pageSize);
        QueryWrapper<User> wrapper = new QueryWrapper<>();

        if (user != null) {
            if (user.getUsername() != null) {
                wrapper.like("username", user.getUsername());
            }
            if (user.getRole() != null) {
                wrapper.eq("role", user.getRole());
            }
        }
        return userMapper.selectPage(page, wrapper);
    }

    @Override
    public User getUserByUsername(String username) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("username", username);
        return userMapper.selectOne(wrapper);
    }

    @Override
    public User getByUid(Long uid) {
        if (uid == null) return null;
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("uid", uid).last("limit 1");
        return userMapper.selectOne(wrapper);
    }

    @Override
    public User getById(Integer id) {
        return userMapper.selectById(id);
    }

    @Override
    public int deleteUsers(List<Integer> ids) {
        return userMapper.deleteBatchIds(ids);
    }

    @Override
    public boolean createUser(User user) {
        if (user.getUid() == null) {
            long newUid = idWorker.nextId();
            user.setUid(newUid);
        }
        return userMapper.insert(user) > 0;
    }

    @Override
    public boolean updateUser(User user) {
        if (user == null || user.getUid() == null) {
            return false;
        }

        User dbUser = getByUid(user.getUid());
        if (dbUser == null) {
            return false;
        }
        user.setId(dbUser.getId());
        return userMapper.updateById(user) > 0;
    }

    @Override
    public boolean validateUser(String username, String password) {
        User dbUser = getUserByUsername(username);
        return dbUser != null && dbUser.getPassword().equals(password);
    }

    @Override
    public int deleteUsersByUid(List<Long> userUids) {
        if (userUids == null || userUids.isEmpty()) return 0;

        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.in("uid", userUids);
        List<User> userList = userMapper.selectList(wrapper);
        if (userList == null || userList.isEmpty()) return 0;

        List<Integer> idList = userList.stream().map(User::getId).collect(Collectors.toList());
        return userMapper.deleteBatchIds(idList);
    }

    @Override
    public int batchCreateUsers(List<RegisterRequestDTO> users) {
        if (users == null || users.isEmpty()) return 0;

        List<User> userList = new ArrayList<>();
        for (RegisterRequestDTO dto : users) {
            if (StrUtil.isBlank(dto.getUsername()) || StrUtil.isBlank(dto.getPassword())) {
                continue;
            }
            User user = new User();
            user.setUid(idWorker.nextId()); // ✅ uid 必须生成
            user.setUsername(dto.getUsername());
            user.setPassword(dto.getPassword()); // 可加密
            user.setRole("user");
            user.setCreatedAt(LocalDateTime.now());
            userList.add(user);
        }

        for (User u : userList) {
            userMapper.insert(u); // 可替换为批量插入方式
        }

        return userList.size();
    }

    @Override
    public boolean updateUserPassword(User user) {
        return userMapper.updateById(user) > 0;
    }

    @Override
    public boolean updateUserProfile(User user) {
        return userMapper.updateById(user) > 0;
    }

    @Override
    public boolean updateUserAvatar(Long uid, String avatarUrl) {
        User dbUser = getByUid(uid);
        if (dbUser == null) {
            return false;
        }

        User updateUser = new User();
        updateUser.setId(dbUser.getId());
        updateUser.setAvatar(avatarUrl);

        return userMapper.updateById(updateUser) > 0;
    }
}
