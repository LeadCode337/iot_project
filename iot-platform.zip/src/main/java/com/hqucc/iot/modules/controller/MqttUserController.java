package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.dto.MqttUserDTO;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;


@Api(tags = "MQTT用户管理")
@RestController
@RequestMapping("/api/mqtt-user")
public class MqttUserController {

    @Autowired
    private MqttUserService mqttUserService;

    @ApiOperation("分页查询MQTT用户")
    @GetMapping("/list")
    public CommonResult<CommonPage<MqttUser>> list(
            MqttUser mqttUser,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "1") Integer pageNum
    ) {
        Long uid = CurrentUserUtils.getUid(); // 获取当前用户的 UID
        String role = CurrentUserUtils.getRole(); // 获取当前用户的角色

        // 只有普通用户才能查看自己创建的 MQTT 用户，管理员可以查看所有用户
        if ("user".equals(role)) {
            mqttUser.setOwnerUid(uid); // 只查询当前用户创建的 MQTT 用户
        }
        Page<MqttUser> page = mqttUserService.list(mqttUser, pageSize, pageNum);
        return CommonResult.success(CommonPage.restPage(page));
    }

    @ApiOperation("批量删除MQTT用户")
    @PostMapping("/delete")
    public CommonResult<Integer> delete(@RequestBody List<Integer> ids) {
        int count = mqttUserService.deleteMqttUserById(ids);
        return count > 0 ? CommonResult.success(count, "成功删除 " + count + " 个用户") : CommonResult.failed("删除失败");
    }

    @GetMapping("/my-list")
    public CommonResult<CommonPage<MqttUser>> myList(
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "1") Integer pageNum
    ) {
        Long currentUid = CurrentUserUtils.getUid();
        Page<MqttUser> page = mqttUserService.listByOwner(currentUid, pageSize, pageNum);
        return CommonResult.success(CommonPage.restPage(page));
    }

    @ApiOperation("根据ID获取MQTT用户")
    @GetMapping("/{id}")
    public CommonResult<MqttUser> getById(@PathVariable Integer id) {
        MqttUser user = mqttUserService.getById(id);
        return user != null ? CommonResult.success(user) : CommonResult.failed("用户不存在");
    }

    @ApiOperation("创建MQTT用户")
    @PostMapping("/create")
    public CommonResult<Boolean> create(@Valid @RequestBody MqttUserDTO userDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return CommonResult.failed("请求参数错误：" + bindingResult.getAllErrors());
        }
        MqttUser mqttUser = new MqttUser();
        mqttUser.setUsername(userDTO.getUsername());
        mqttUser.setOwnerUid(CurrentUserUtils.getUid());
        boolean success = mqttUserService.createUser(mqttUser, userDTO.getPassword());
        return success ? CommonResult.success(true, "创建成功") : CommonResult.failed("创建失败");
    }

    @ApiOperation("更新MQTT用户")
    @PostMapping("/update")
    public CommonResult<Boolean> update(@RequestBody MqttUser user) {
        boolean success = mqttUserService.updateUser(user);
        return success ? CommonResult.success(true, "更新成功") : CommonResult.failed("更新失败");
    }

    @ApiOperation("修改密码")
    @PostMapping("/update-password")
    public CommonResult<Boolean> updatePassword(
            @RequestParam("id") Integer id,
            @RequestParam("newPassword") String newPassword
    ) {
        boolean success = mqttUserService.updatePasswordById(id, newPassword);
        return success ? CommonResult.success(true, "密码修改成功")
                : CommonResult.failed("密码修改失败");
    }
}
