package com.hqucc.iot.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.SensorPageDTO;
import com.hqucc.iot.modules.entity.Device;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.Sensor;
import com.hqucc.iot.modules.mapper.DeviceMapper;
import com.hqucc.iot.modules.mapper.SensorMapper;
import com.hqucc.iot.modules.service.DeviceService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.service.SensorService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SensorServiceImpl implements SensorService {

    @Autowired
    private SensorMapper sensorMapper;

    @Autowired
    private DeviceMapper deviceMapper;

    @Autowired
    private MqttUserService mqttUserService;
    @Autowired
    private DeviceService deviceService;

    @Override
    public IPage<SensorPageDTO> list(Sensor sensor, Integer pageSize, Integer pageNum, List<Long> visibleDeviceUids) {
        String role = CurrentUserUtils.getRole();
        if ("admin".equals(role) || "manager".equals(role)) {
            visibleDeviceUids = null;
        }
        if ("user".equals(role) && (visibleDeviceUids == null || visibleDeviceUids.isEmpty())) {
            visibleDeviceUids = Collections.singletonList(-1L);
        }

        Page<SensorPageDTO> page = new Page<>(pageNum, pageSize);
        return sensorMapper.selectSensorPageDTO(
                page,
                sensor != null ? sensor.getSensorType() : null,
                sensor != null ? sensor.getDeviceUid() : null,
                visibleDeviceUids
        );
    }


    @Override
    public Sensor getBySensorUid(Long sensorUid) {
        QueryWrapper<Sensor> wrapper = new QueryWrapper<>();
        wrapper.eq("sensor_uid", sensorUid).last("limit 1");
        return sensorMapper.selectOne(wrapper);
    }

    @Override
    public boolean createSensor(Sensor sensor) {
        return sensorMapper.insert(sensor) > 0;
    }

    @Override
    public boolean updateSensor(Sensor sensor) {
        if (sensor == null || sensor.getSensorUid() == null) {
            return false;
        }
        Sensor dbSensor = getBySensorUid(sensor.getSensorUid());
        if (dbSensor == null) return false;

        sensor.setId(dbSensor.getId());
        return sensorMapper.updateById(sensor) > 0;
    }

    @Override
    public Sensor getByDeviceUidAndType(Long deviceUid, String sensorType) {
        if (deviceUid == null || sensorType == null) return null;
        QueryWrapper<Sensor> wrapper = new QueryWrapper<>();
        wrapper.eq("device_uid", deviceUid)
                .eq("sensor_type", sensorType)
                .last("limit 1");
        return sensorMapper.selectOne(wrapper);
    }

    @Override
    public Sensor getById(Integer id) {
        return sensorMapper.selectById(id);
    }

    @Override
    public int deleteSensors(List<Integer> ids) {
        return sensorMapper.deleteBatchIds(ids);
    }

    public List<Long> getSensorUidsByDeviceUids(List<Long> deviceUids) {
        if (deviceUids == null || deviceUids.isEmpty()) return Collections.emptyList();
        QueryWrapper<Sensor> wrapper = new QueryWrapper<>();
        wrapper.in("device_uid", deviceUids);
        List<Sensor> sensors = sensorMapper.selectList(wrapper);
        return sensors.stream().map(Sensor::getSensorUid).collect(Collectors.toList());
    }
}