package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.dto.SensorPageDTO;
import com.hqucc.iot.modules.entity.MqttUser;
import com.hqucc.iot.modules.entity.Sensor;
import com.hqucc.iot.modules.service.DeviceService;
import com.hqucc.iot.modules.service.MqttUserService;
import com.hqucc.iot.modules.service.SensorService;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Api(tags = "传感器管理")
@RestController
@RequestMapping("/api/sensor")
public class SensorController {

    @Autowired
    private SensorService sensorService;

    @Autowired
    private DeviceService deviceService;

    @Autowired
    private MqttUserService mqttUserService;

    @ApiOperation("分页查询传感器列表")
    @GetMapping("/list")
    @ResponseBody
    public CommonResult<CommonPage<SensorPageDTO>> list(
            Sensor sensor,
            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
            @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum
    ) {
        Long uid = CurrentUserUtils.getUid();
        String role = CurrentUserUtils.getRole();

        List<Long> visibleDeviceUids = null;
        if ("user".equals(role)) {
            List<MqttUser> mqttUsers = mqttUserService.listByOwnerUid(uid);
            List<Long> mqttUids = mqttUsers.stream().map(MqttUser::getMqttUid).collect(Collectors.toList());
            visibleDeviceUids = mqttUids.isEmpty() ? Collections.singletonList(-1L)
                    : deviceService.getDeviceUidsByMqttUidList(mqttUids);
        }

        IPage<SensorPageDTO> page = sensorService.list(sensor, pageSize, pageNum, visibleDeviceUids);
        return CommonResult.success(CommonPage.restPage(page));
    }


    @ApiOperation("创建传感器")
    @PostMapping("/create")
    @ResponseBody
    public CommonResult<Boolean> create(@RequestBody Sensor sensor) {
        boolean success = sensorService.createSensor(sensor);
        if (success) {
            return CommonResult.success(true, "创建传感器成功");
        }
        return CommonResult.failed("创建传感器失败");
    }

    @ApiOperation("更新传感器信息")
    @PostMapping("/update")
    @ResponseBody
    public CommonResult<Boolean> update(@RequestBody Sensor sensor) {
        boolean success = sensorService.updateSensor(sensor);
        if (success) {
            return CommonResult.success(true, "更新传感器成功");
        }
        return CommonResult.failed("更新传感器失败");
    }

    @ApiOperation("根据ID获取传感器")
    @GetMapping("/{id}")
    public CommonResult<Sensor> getSensorById(@PathVariable Integer id) {
        Sensor sensor = sensorService.getById(id);
        if (sensor != null) {
            return CommonResult.success(sensor);
        }
        return CommonResult.failed("传感器不存在");
    }

    @ApiOperation("批量删除传感器")
    @PostMapping("/delete")
    public CommonResult<Integer> delete(@RequestBody List<Integer> ids) {
        int count = sensorService.deleteSensors(ids);
        if (count > 0) {
            return CommonResult.success(count, "成功删除 " + count + " 个传感器");
        }
        return CommonResult.failed("删除失败");
    }
}