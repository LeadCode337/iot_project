package com.hqucc.iot.modules.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.common.api.CommonPage;
import com.hqucc.iot.common.api.CommonResult;
import com.hqucc.iot.modules.entity.Log;
import com.hqucc.iot.modules.service.LogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "日志管理")
@RestController
@RequestMapping("/api/log")
public class LogController {

    @Autowired
    private LogService logService;

    @ApiOperation("分页查询日志列表")
    @GetMapping("/list")
    @ResponseBody
    public CommonResult<CommonPage<Log>> list(
            Log log,
            @RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
            @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum
    ) {
        Page<Log> logPage = logService.list(log, pageSize, pageNum);
        return CommonResult.success(CommonPage.restPage(logPage));
    }

    @ApiOperation("创建日志")
    @PostMapping("/create")
    @ResponseBody
    public CommonResult<Boolean> create(@RequestBody Log logEntity) {
        boolean success = logService.createLog(logEntity);
        if (success) {
            return CommonResult.success(true, "创建日志成功");
        }
        return CommonResult.failed("创建日志失败");
    }

    @ApiOperation("根据ID获取日志")
    @GetMapping("/{id}")
    public CommonResult<Log> getLogById(@PathVariable Integer id) {
        Log entity = logService.getById(id);
        if (entity != null) {
            return CommonResult.success(entity);
        }
        return CommonResult.failed("日志不存在");
    }

    @ApiOperation("批量删除日志")
    @PostMapping("/delete")
    public CommonResult<Integer> delete(@RequestBody List<Integer> ids) {
        int count = logService.deleteLogs(ids);
        if (count > 0) {
            return CommonResult.success(count,"成功删除 " + count + " 条日志");
        }
        return CommonResult.failed("删除日志失败");
    }
}
