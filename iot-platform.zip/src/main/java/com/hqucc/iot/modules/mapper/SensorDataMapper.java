package com.hqucc.iot.modules.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hqucc.iot.modules.dto.SensorDataPageDTO;
import com.hqucc.iot.modules.entity.SensorData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SensorDataMapper extends BaseMapper<SensorData> {
    Page<SensorDataPageDTO> selectPageWithJoin(Page<?> page, @Param("uids") List<Long> sensorUids, @Param("type") String type);
}