package com.hqucc.iot.modules.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("mqtt_acl")
public class MqttAcl {
  @TableId(type = IdType.AUTO)
  private Integer id;
  private String username;
  private String permission;
  private String action;
  private String topic;
  private Integer qos;
  private Integer retain;
  @TableField("created_at")
  private LocalDateTime createdAt;

  @TableField("mqtt_uid")
  private Long mqttUid;
}