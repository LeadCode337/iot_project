package com.hqucc.iot.common.constant;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class AuthWhiteList {

    public static final Set<String> EXCLUDE_URLS = new HashSet<>(Arrays.asList(
            "/api/user/login",
            "/api/user/register",
            "/doc.html",
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/swagger-resources/**",
            "/v2/api-docs",
            "/webjars/**"
    ));

    public static final String SWAGGER_EXCLUDE_REGEX = "^(?!/api/user/(login|register)).*";
}
