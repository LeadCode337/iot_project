package com.hqucc.iot.common.utils;

import com.hqucc.iot.common.config.CosProperties;
import com.hqucc.iot.modules.utils.CurrentUserUtils;
import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.model.PutObjectRequest;
import com.qcloud.cos.region.Region;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Slf4j
@Component
@RequiredArgsConstructor
public class CosUtils {

    private final CosProperties cosProperties;

    /** 最大文件大小：2MB */
    private static final long MAX_FILE_SIZE = 2 * 1024 * 1024;

    /** 允许上传的图片后缀 */
    private static final List<String> ALLOWED_IMAGE_EXTENSIONS = Arrays.asList(".jpg", ".jpeg", ".png", ".gif", ".bmp");

    /**
     * 上传文件到COS并返回公网访问URL
     */
    public String uploadFile(MultipartFile file, String subFolder) {
        if (file.isEmpty()) {
            throw new RuntimeException("上传文件不能为空");
        }

        // 检查文件大小
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new RuntimeException("文件大小不能超过 2MB");
        }

        // 检查文件类型
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || !isAllowedImageExtension(originalFilename)) {
            throw new RuntimeException("只允许上传图片类型文件（jpg、jpeg、png、gif、bmp）");
        }

        COSCredentials credentials = new BasicCOSCredentials(cosProperties.getAccessKey(), cosProperties.getSecretKey());
        ClientConfig clientConfig = new ClientConfig(new Region(cosProperties.getRegionName()));
        COSClient cosClient = new COSClient(credentials, clientConfig);

        try {
            String fileExt = originalFilename.substring(originalFilename.lastIndexOf(".")).toLowerCase();

            LocalDate now = LocalDate.now();
            String datePath = now.getYear() + "/" + String.format("%02d", now.getMonthValue()) + "/" + String.format("%02d", now.getDayOfMonth());

            Long uid = CurrentUserUtils.getUid();
            String userPath = uid != null ? uid.toString() : "anonymous";

            String key = (cosProperties.getFolderPrefix() + "/" +
                    (subFolder != null ? subFolder + "/" : "") +
                    userPath + "/" + datePath + "/" +
                    UUID.randomUUID().toString().replace("-", "") + fileExt)
                    .replaceAll("/+", "/");

            File tempFile = File.createTempFile("cos_upload_", null);
            file.transferTo(tempFile);

            PutObjectRequest putObjectRequest = new PutObjectRequest(cosProperties.getBucketName(), key, tempFile);
            cosClient.putObject(putObjectRequest);

            String url = "https://" + cosProperties.getBaseUrl() + "/" + key;
            log.info("✅ 文件上传成功: {}", url);

            return url;
        } catch (IOException e) {
            log.error("❌ 文件上传失败", e);
            throw new RuntimeException("上传文件失败", e);
        } finally {
            cosClient.shutdown();
        }
    }

    /**
     * 检查文件后缀是否允许
     */
    private boolean isAllowedImageExtension(String filename) {
        String lowerCaseName = filename.toLowerCase();
        return ALLOWED_IMAGE_EXTENSIONS.stream().anyMatch(lowerCaseName::endsWith);
    }
}
