package com.hqucc.iot.common.config;

import com.hqucc.iot.common.constant.AuthWhiteList;
import com.hqucc.iot.modules.security.CustomAccessDeniedHandler;
import com.hqucc.iot.modules.security.CustomAuthenticationEntryPoint;
import com.hqucc.iot.modules.utils.JwtAuthFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http,
                                           JwtAuthFilter jwtAuthFilter,
                                           AccessDeniedHandler accessDeniedHandler,
                                           AuthenticationEntryPoint authenticationEntryPoint) throws Exception {

        http.csrf().disable()
                .cors().and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()

                // ✅ 放行跨域预检
                .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                // ✅ 放行白名单接口
                .antMatchers(AuthWhiteList.EXCLUDE_URLS.toArray(new String[0])).permitAll()

                // ✅ 角色控制接口
                .antMatchers("/api/admin/**").hasAuthority("admin")
                .antMatchers("/api/manager/**").hasAnyAuthority("admin", "manager")
                .antMatchers("/api/user/**").hasAnyAuthority("admin", "manager", "user")

                // ✅ 其它接口需登录
                .anyRequest().authenticated()
                .and()

                // ✅ JWT 过滤器拦截请求
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)

                // ✅ 统一权限异常处理
                .exceptionHandling()
                .accessDeniedHandler(accessDeniedHandler)           // 403 无权限
                .authenticationEntryPoint(authenticationEntryPoint); // 401 未认证

        return http.build();
    }

    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        return new CustomAccessDeniedHandler();
    }

    @Bean
    public AuthenticationEntryPoint authenticationEntryPoint() {
        return new CustomAuthenticationEntryPoint();
    }
}
